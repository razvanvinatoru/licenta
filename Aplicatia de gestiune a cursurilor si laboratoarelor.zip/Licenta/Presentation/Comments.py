from Presentation.Server import app
from Data.Utils.DateUtils import get_datetime_now, format_comment_date, format_date_tooltip
from flask import request
from flask_login import current_user, login_required
import json
from Bussiness.Services.QuestionCourseService import QuestionCourseService
from Bussiness.Services.QuestionLaboratoryService import QuestionLaboratoryService

_question_course_service = QuestionCourseService()
_question_laboratory_service = QuestionLaboratoryService()


@app.route('/add_question_course')
def add_question_course():
    question_text = request.args["question_text"]
    course_uuid = request.args["course_uuid"]

    question_uuid = _question_course_service.add(
        **{
            'user_uuid': current_user.uuid,
            'course_uuid': course_uuid,
            'text': question_text,
            'is_edited': False,
            'date': get_datetime_now(),
            'edit_date': None
        }
    )

    question = {
        "uuid": question_uuid,
        "author_fullname": current_user.lastname + " " + current_user.firstname,
        "date": "chiar acum",
        "text": question_text,
        "author": True
    }
    return json.dumps(question)


@app.route('/add_question_laboratory')
def add_question_laboratory():
    question_text = request.args["question_text"]
    course_uuid = request.args["laboratory_uuid"]

    _question_laboratory_service.add_question(
        **{
            'user_uuid': current_user.uuid,
            'laboratory_uuid': course_uuid,
            'text': question_text,
            'is_edited': False,
            'date': get_datetime_now(),
            'edit_date': None
        }
    )

    question = {
        "author_fullname": current_user.lastname + " " + current_user.firstname,
        "date": "chiar acum",
        "text": question_text,
        "author": True
    }
    return json.dumps(question)


@app.route('/delete_question', methods=['DELETE'])
@login_required
def delete_question():
    uuid = request.form['uuid']

    _question_course_service.delete_by_uuid(uuid)

    return json.dumps({"message": "success"})


@app.route('/edit_comment')
@login_required
def edit_comment():
    print(request.args)
    uuid = request.args["uuid"]
    new_text = request.args["new_text"]

    question = _question_course_service.get_by_uuid(uuid)
    _question_course_service.update(uuid, **{
        'text': new_text,
        'is_edited': True,
        'edit_date': get_datetime_now()
    })
    comment_date = question.date

    return json.dumps({"new_text" : new_text,
                       "comment_date": format_comment_date(comment_date),
                       "author_name": current_user.lastname + " " + current_user.firstname,
                       "edit_date": format_date_tooltip(get_datetime_now())})
