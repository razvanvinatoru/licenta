from Presentation.Server import app
from flask import render_template, redirect, url_for, Blueprint


@app.errorhandler(404)
def error_404(e):
    return render_template("errors/error_404.html")


@app.errorhandler(401)
def error_401(e):
    return redirect(url_for("login"))
