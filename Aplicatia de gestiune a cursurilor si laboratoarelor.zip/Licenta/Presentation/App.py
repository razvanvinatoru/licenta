import re
from Presentation.Server import app
from flask import render_template, flash, redirect, url_for
from flask_login import login_required, current_user
from Bussiness.Services.LaboratoryService import LaboratoryService
from Bussiness.Services.ContactMessageService import ContactMessageService
from Bussiness.Services.UserService import UserService
from Bussiness.Services.StudentService import StudentService
from Bussiness.Services.HardcodedProfessorService import HardcodedProfessorService
from Data.Forms.EditDetailsForm import EditDetailsForm
from Data.Forms.EditPasswordForm import EditPasswordForm
from Data.Forms.ContactMessageForm import ContactMessagesForm
from Data.Utils.CourseUtils import return_courses_json, return_laboratories_json
from Data.Utils.DateUtils import get_datetime_now

_user_service = UserService()
_student_service = StudentService()
_laboratory_service = LaboratoryService()
_contact_message_service = ContactMessageService()
_hardcoded_professor_service = HardcodedProfessorService()


@app.route('/app/')
@login_required
def application():
    return redirect(url_for('courses'))


@app.route('/app/courses/')
@login_required
def courses():
    _courses_json = return_courses_json()
    _laboratories_json = return_laboratories_json()

    return render_template("application/courses.html", courses_json=_courses_json,
                           laboratories_json=_laboratories_json)


@app.route('/app/laboratories/')
@login_required
def laboratories():
    _courses_json = return_courses_json()
    _laboratories_json = return_laboratories_json()
    return render_template("application/laboratories.html",
                           courses_json=_courses_json, laboratories_json=_laboratories_json)


@app.route('/app/details/', methods=["GET", "POST"])
@login_required
def details():
    _courses_json = return_courses_json()
    _laboratories_json = return_laboratories_json()

    edit_details_form = EditDetailsForm(
        prefix="edit_details_form",
        group=current_user.student[0].group,
        year=current_user.student[0].year
    )
    edit_password_form = EditPasswordForm(prefix="edit_password_form")

    if edit_details_form.submitName.data:
        if edit_details_form.name.data == "":
            flash(f"Campul cu numele nu poate fi gol!", "danger")
            return redirect(url_for('details'))
        elif len(edit_details_form.name.data) < 6 or len(edit_details_form.name.data) > 40:
            flash(f"Campul cu numele trebuie sa fie intre 6 si 40 de litere", 'danger')
            return redirect(url_for('details'))
        elif not re.match("^[a-zA-Z ]+$", edit_details_form.name.data):
            flash(f"Numele trebuie sa contina doar litere!", 'danger')
            return redirect(url_for('details'))

        names = edit_details_form.name.data.strip().split()
        lastname = ""
        firstname = ""

        for i in range(0, len(names)):
            if i == 0:
                lastname = names[i]
            else:
                firstname += names[i] + " "

        _user_service.update_lastname(current_user.email, lastname.strip())
        _user_service.update_firstname(current_user.email, firstname.strip())

    if edit_details_form.submitEmail.data:
        if edit_details_form.email.data == "":
            flash(f"Campul cu emailul nu poate fi gol!", "danger")
            return redirect(url_for('details'))

        email_inserted = edit_details_form.email.data.lower().strip()
        token = sendConfirmationChangeEmail(current_user.email, email_inserted)
        _request_change_email_service.add_request_change_email(current_user.id, current_user.email, email_inserted, token, GetDateTimeNow())

        flash(f"Un email de confirmare a fost trimis la vechea adresa de email, dupa confirmare email-ul va fii schimbat cu success!","warning")
        redirect(url_for('details'))

    if edit_details_form.submitGroup.data:
        _student_service.update_group(current_user.email, edit_details_form.group.data)

    if edit_details_form.submitYear.data:
        if edit_details_form.year.data == "cursant":
            _student_service.update_group(current_user.email, None)
        _student_service.update_year(current_user.email, edit_details_form.year.data)

    if edit_details_form.submitStudentDescription.data:
        _student_service.update_description(current_user.email, edit_details_form.student_description.data.strip())

    if edit_password_form.submitPassword.data:
        hash_new_password = bcrypt.generate_password_hash(edit_password_form.new_password.data).decode('utf-8')
        if edit_password_form.password.data == "" or edit_password_form.new_password == "" or edit_password_form.confirm_new_password == "":
            flash(f"Campurile nu au voie sa fie goale!", "danger")
            return render_template("application/details.html", edit_details_form=edit_details_form, edit_password_form=edit_password_form, pressed_button="change_password", displayDetailsActive="",
                                   changePasswordActive="active")
        elif not bcrypt.check_password_hash(user.password, edit_password_form.password.data):
            flash(f"Parola actuala introdusa este gresita, incercati din nou!", "danger")
            return render_template("application/details.html", edit_details_form=edit_details_form, edit_password_form=edit_password_form, pressed_button="change_password", displayDetailsActive="",
                                   changePasswordActive="active")
        elif bcrypt.check_password_hash(user.password, edit_password_form.new_password.data):
            flash(f"Parola noua nu poate fi aceeasi cu parola actuala, incercati din nou!", "danger")
            return render_template("application/details.html", edit_details_form=edit_details_form, edit_password_form=edit_password_form, pressed_button="change_password", displayDetailsActive="",
                                   changePasswordActive="active")
        elif edit_password_form.new_password.data != edit_password_form.confirm_new_password.data:
            flash(f"Parola noua si confirmarea parolei noi nu sunt la fel!", "danger")
            return render_template("application/details.html", edit_details_form=edit_details_form, edit_password_form=edit_password_form, pressed_button="change_password", displayDetailsActive="",
                                   changePasswordActive="active")

        _user_service.update_password_user(user, hash_new_password)
        flash(f"Parola a fost schimbata cu success!", "success")
        return render_template("application/details.html", edit_details_form=edit_details_form, edit_password_form=edit_password_form, pressed_button="change_password", displayDetailsActive="",
                               changePasswordActive="active")

    return render_template("application/details.html",
                           editDetailsForm=edit_details_form,
                           editPasswordForm=edit_password_form,
                           displayDetailsActive="active",
                           changePasswordActive="",
                           courses_json=_courses_json,
                           laboratories_json=_laboratories_json)


@app.route('/app/contact/', methods=["GET", "POST"])
@login_required
def contact():
    _courses_json = return_courses_json()
    _laboratories_json = return_laboratories_json()

    contact_messages_form = ContactMessagesForm()
    if contact_messages_form.submit.data:
        if contact_messages_form.text.data.isspace():
            flash(f"Textul mesajului nu poate contine doar spatii, endline-uri...!", "danger")
        elif len(contact_messages_form.text.data) > 300:
            flash(f"Textul mesajului nu poate contine mai mult de 300 de caractere!", "danger")
        else:
            _contact_message_service.add(**{
                'email_reviewer': current_user.email,
                'text': contact_messages_form.text.data.strip(),
                'message_date': get_datetime_now()
            })
            flash(f"Mesajul a fost trimis cu success!", "success")
    return render_template("application/contact.html",
                           contactMessagesForm=contact_messages_form,
                           courses_json=_courses_json,
                           laboratories_json=_laboratories_json)
