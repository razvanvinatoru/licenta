from flask import Flask
from flask_bcrypt import Bcrypt
from flask_sqlalchemy import SQLAlchemy
from flask_script import Manager, Server
from flask_migrate import Migrate, MigrateCommand
from flask_login import LoginManager
from flask_mail import Mail, Message

app = Flask(__name__)

app.config['SECRET_KEY'] = 'arandomstringhardtobebroken'
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:test123@localhost/db_licenta'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'fii.courses.laboratories@gmail.com'
app.config['MAIL_PASSWORD'] = 'parola_fii_app'
app.config['MAIL_USE_SSL'] = True
app.config['UPLOAD_FOLDER'] = 'D:\\Projects\\Licenta\\Presentation\\static\\uploads'

db = SQLAlchemy(app)

migrate = Migrate(app, db)
manager = Manager(app)

manager.add_command('runserver', Server(use_debugger=True, use_reloader=True))
manager.add_command('db', MigrateCommand)
mail = Mail(app)

bcrypt = Bcrypt(app)
login_manager = LoginManager(app)

from Data.Domain.User import User
from Data.Domain.Student import Student
from Data.Domain.PendingAccount import PendingAccounts
from Data.Domain.Course import Course
from Data.Domain.CourseExam import CourseExam
from Data.Domain.CourseExamQuestion import CourseExamQuestion
from Data.Domain.CourseExamResult import CourseExamResult
from Data.Domain.CourseExamQuestionAnswer import CourseExamQuestionAnswer
from Data.Domain.Laboratory import Laboratory
from Data.Domain.Professor import Professor
from Data.Domain.HardcodedProfessor import HardcodedProfessor
from Data.Domain.ProfessorCourse import ProfessorCourse
from Data.Domain.ProfessorLaboratory import ProfessorLab
from Data.Domain.QuestionCourse import QuestionCourse
from Data.Domain.QuestionLaboratory import QuestionLaboratory
from Data.Domain.LaboratoryPdf import LaboratoryPdf
from Data.Domain.CoursePdf import CoursePdf
from Data.Domain.LaboratoryHomework import LaboratoryHomework
from Data.Domain.LaboratoryHomeworkSent import LaboratoryHomeworkSent


from Presentation import Home
from Presentation import Error
from Presentation import Authentication
from Presentation import App
from Presentation import Comments

from Presentation.Course import course_bp
from Presentation.Laboratory import laboratory_bp

app.register_blueprint(course_bp)
app.register_blueprint(laboratory_bp)
