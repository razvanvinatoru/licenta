from flask import render_template, flash, redirect, url_for
from flask_login import login_user, current_user, logout_user, login_required
from Presentation.Server import app
from Presentation.Server import bcrypt
from Data.Utils.DateUtils import get_datetime_now
from Data.Utils.AuthenticationUtils import verify_token
from Data.Utils.AuthenticationUtils import verify_login_form
from Data.Utils.AuthenticationUtils import send_password_email
from Data.Utils.AuthenticationUtils import get_random_password
from Data.Utils.AuthenticationUtils import verify_register_form
from Data.Utils.AuthenticationUtils import send_confirmation_email
from Data.Utils.AuthenticationUtils import verify_forgot_password_form

from Data.Forms.LoginForm import LoginForm
from Data.Forms.RegistrationForm import RegistrationForm
from Data.Forms.ForgotPasswordForm import ForgotPasswordForm

from Bussiness.Services.UserService import UserService
from Bussiness.Services.StudentService import StudentService
from Bussiness.Services.PendingAccountService import PendingAccountService

_user_service = UserService()
_student_service = StudentService()
_pending_account_service = PendingAccountService()


@app.route('/register')
def register():
    return redirect(url_for('register_student'))


@app.route('/register/student', methods=["GET", "POST"])
def register_student():
    form = RegistrationForm()

    if form.submit.data:

        student_data = {
            "lastname": form.lastname.data,
            "firstname": form.firstname.data,
            "email": form.email.data,
            "password": form.password.data,
            "confirm_password": form.confirm_password.data,
        }

        verification_result = verify_register_form(student_data)

        if verification_result["passed"]:
            hashed_password = bcrypt.generate_password_hash(form.password.data).decode('UTF-8')
            token = send_confirmation_email(
                form.email.data,
                form.lastname.data.title(),
                form.firstname.data.title()
            )

            _pending_account_service.add_pending_account(
                _lastname=form.lastname.data.title(),
                _firstname=form.firstname.data.title(),
                _email=form.email.data.lower(),
                _password=hashed_password,
                _token=token,
                _type_user="student",
                _register_date=get_datetime_now())

            flash(verification_result["message"], "success")
            return redirect(url_for('login'))
        else:
            flash(verification_result["message"], "danger")
            return redirect(url_for('register_student'))

    return render_template("authentication/register_student.html", form=form)


@app.route('/register/professor', methods=["GET", "POST"])
def register_professor():
    form = RegistrationForm()

    if form.submit.data:

        professor_data = {
            "lastname": form.lastname.data,
            "firstname": form.firstname.data,
            "email": form.email.data,
            "password": form.password.data,
            "confirm_password": form.confirm_password.data,
        }

        verification_result = verify_register_form(professor_data)

        if verification_result["passed"]:
            hashed_password = bcrypt.generate_password_hash(form.password.data).decode('UTF-8')

            _pending_account_service.add_pending_account(
                _lastname=form.lastname.data.title(),
                _firstname=form.firstname.data.title(),
                _email=form.email.data.lower(),
                _password=hashed_password,
                _token="",
                _type_user="professor",
                _register_date=get_datetime_now())

            flash(verification_result["message"], "success")
            return redirect(url_for('login'))
        else:
            flash(verification_result["message"], "danger")
            return redirect(url_for('register_student'))

    return render_template("authentication/register_professor.html", form=form)


@app.route('/login', methods=["GET", "POST"])
def login():
    form = LoginForm()

    if form.submit.data:

        data = {
            "email": form.email.data,
            "password": form.password.data
        }

        verification_result = verify_login_form(data)

        if verification_result["passed"]:

            user = _user_service.get_first_user_by_email(data["email"].lower())

            if user and bcrypt.check_password_hash(user.password, form.password.data):
                login_user(user, remember=True)
                flash(verification_result["message"], "success")
                return redirect(url_for('application'))
        else:
            flash(verification_result["message"], "danger")
            return redirect(url_for('login'))

    return render_template("authentication/login.html", form=form)


@app.route('/confirm_email/<token>')
def confirm_email(token):
    if not verify_token(token):
        flash("Token-ul a expirat, inregistrati-va din nou!", 'danger')
        return redirect(url_for('login'))

    pending_accounts = _pending_account_service.get_all_pending_accounts()
    for pending_account in pending_accounts:
        if pending_account.token == token:
            if pending_account.type_user == "student":
                _student_service.add_student(
                    _uuid=pending_account.uuid,
                    _lastname=pending_account.lastname,
                    _firstname=pending_account.firstname,
                    _email=pending_account.email,
                    _password=pending_account.password
                )

                _pending_account_service.delete_pending_account(pending_account.id)

    flash("Ai confirmat emailul cu succes, acum te poti conecta!", 'success')
    return redirect(url_for('login'))


@app.route('/forgot_password', methods=["GET", "POST"])
def forgot_password():
    form = ForgotPasswordForm()

    if form.submit.data:
        data = {
            "email": form.email.data
        }

        verification_result = verify_forgot_password_form(data)

        if verification_result["passed"]:
            email = form.email.data.lower()
            random_password = get_random_password()
            new_password = bcrypt.generate_password_hash(random_password).decode('utf-8')
            _user_service.update_password(email, new_password)
            send_password_email(email, random_password)
            flash(verification_result["message"], "success")
        else:
            flash(verification_result["message"], "danger")
            return redirect(url_for('forgot_password'))

    return render_template("authentication/forgot_password.html", form=form)


@app.route('/app/logout/')
@login_required
def logout():
    logout_user()
    flash("Te-ai delogat cu succes!", "success")
    return redirect(url_for('login'))
