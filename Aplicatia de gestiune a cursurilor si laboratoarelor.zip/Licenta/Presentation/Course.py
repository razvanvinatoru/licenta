import json
from random import shuffle
from flask import Blueprint, render_template, request
from flask_login import login_required, current_user
from Data.Utils.DateUtils import format_comment_date
from Bussiness.Services.UserService import UserService
from Bussiness.Services.CourseService import CourseService
from Bussiness.Services.QuestionCourseService import QuestionCourseService
from Bussiness.Services.HardcodedProfessorService import HardcodedProfessorService
from Bussiness.Services.CoursePdfService import CoursePdfService
from Bussiness.Services.CourseExamService import CourseExamService
from Bussiness.Services.CourseExamQuestionService import CourseExamQuestionService
from Bussiness.Services.CourseExamQuestionAnswerService import CourseExamQuestionAnswerService
from Bussiness.Services.CourseExamResultService import CourseExamResultService
from Data.Utils.CourseUtils import return_courses_json, return_laboratories_json

course_bp = Blueprint('course_bp', __name__)

_user_service = UserService()
_course_service = CourseService()
_course_pdf_service = CoursePdfService()
_course_exam_service = CourseExamService()
_question_course_service = QuestionCourseService()
_course_exam_result_service = CourseExamResultService()
_hardcoded_professor_service = HardcodedProfessorService()
_course_exam_question_service = CourseExamQuestionService()
_course_exam_question_answer_service = CourseExamQuestionAnswerService()


@course_bp.route('/get_course_exam_data/<course_pdf_uuid>', methods=['GET'])
@login_required
def get_course_exam_data(course_pdf_uuid):
    course_exam = _course_exam_service.get_by_course_pdf_uuid(course_pdf_uuid).as_dict
    return json.dumps(course_exam, default=str)


@course_bp.route('/get_exam_questions_answers/<course_exam_uuid>', methods=['GET'])
@login_required
def get_course_exam_questions_answers(course_exam_uuid):
    data = list()

    course_exam = _course_exam_service.get_by_uuid(course_exam_uuid)
    exam_questions = _course_exam_question_service.get_by_course_exam_uuid(course_exam_uuid)

    shuffle(exam_questions)

    for exam_question in exam_questions:
        answers = list()
        exam_question_answers = _course_exam_question_answer_service.get_by_course_exam_question_uuid(exam_question.uuid)
        for exam_question_answer in exam_question_answers:
            answers.append({
                'name': exam_question_answer.answer,
                'is_correct': exam_question_answer.is_correct
            })
        data.append({
            'name': exam_question.question,
            'score': exam_question.score,
            'answers': answers,
            'time': course_exam.duration_minutes
        })
    return json.dumps(data)


@course_bp.route('/app/course/<course_uuid>')
@login_required
def course(course_uuid):
    _courses_json = return_courses_json()
    _laboratories_json = return_laboratories_json()

    _course = _course_service.get_course_by_uuid(course_uuid)

    _questions = _question_course_service.get_by_course_uuid(course_uuid)

    professor_courses = _course_service.get_professor_courses_by_course_uuid(course_uuid)

    _hardcoded_professors = [
        _hardcoded_professor_service.get_first_professor_by_uuid(professor_course.id_professor).full_name
        for professor_course in professor_courses
    ]

    course_pdfs = _course_pdf_service.get_by_course_uuid(course_uuid)

    course_pdfs_exams = list()
    for course_pdf_ in course_pdfs:
        course_exam = _course_exam_service.get_by_course_pdf_uuid(course_pdf_.uuid)
        course_exam_result = _course_exam_result_service.get_by_course_exam_and_student_uuid(
            course_exam.uuid, current_user.uuid
        )

        if not course_exam_result:
            exam_status = 'available'
        else:
            if course_exam_result.result < 5:
                exam_status = 'not passed'
            else:
                exam_status = 'passed'

        course_pdfs_exams.append({
            'course_pdf': course_pdf_,
            'exam_status': exam_status
        })

    questions = []

    for _question in _questions:
        _user = _user_service.get_first_user_by_uuid(_question.user_uuid)

        question = {
            "uuid": _question.uuid,
            "author_fullname": _user.lastname + " " + _user.firstname,
            "date": format_comment_date(_question.date),
            "text": _question.text,
            'is_edited': _question.is_edited,
            'edit_date': _question.edit_date
        }

        if current_user.uuid == _question.user_uuid:
            question["author"] = True
        else:
            question["author"] = False
        questions.append(question)

    return render_template(
        "application/course.html",
        course_uuid=course_uuid,
        course_name=_course.name,
        courses_json=_courses_json,
        laboratories_json=_laboratories_json,
        course_pdfs_exams=course_pdfs_exams,
        questions=questions,
        professors=_hardcoded_professors,
        description=_course.description
    )


@course_bp.route('/app/course/<course_uuid>/<pdf_name>')
@login_required
def course_pdf(course_uuid, pdf_name):
    _courses_json = return_courses_json()
    _laboratories_json = return_laboratories_json()

    _pdf_name = pdf_name.split(".pdf")[0]

    return render_template("application/course_pdf.html", course_uuid=course_uuid, pdf_name=_pdf_name,
                           courses_json=_courses_json, laboratories_json=_laboratories_json)


@course_bp.route('/app/course/send_exam_results', methods=['POST'])
@login_required
def send_exam_results():
    data = json.loads(request.get_data().decode('UTF-8'))

    _course_exam_result_service.add(**{
        'course_exam_uuid': data['course_exam_uuid'],
        'student_uuid': current_user.uuid,
        'result': data['score']
    })
    return json.dumps({'message': 'success'})


@course_bp.route('/app/course/get_course_exam_result_grade/<course_pdf_uuid>')
@login_required
def get_course_exam_result_grade(course_pdf_uuid):
    course_exam_uuid = _course_exam_service.get_by_course_pdf_uuid(course_pdf_uuid).uuid
    course_exam_result = _course_exam_result_service.get_by_course_exam_and_student_uuid(
        course_exam_uuid, current_user.uuid
    )
    return json.dumps({'grade': course_exam_result.result})
