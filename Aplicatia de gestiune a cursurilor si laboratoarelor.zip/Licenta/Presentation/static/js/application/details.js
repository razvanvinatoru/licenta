function goToEditDetails(event, nth_of_line){
    event.preventDefault();
    document.getElementsByClassName('default-left-side')[nth_of_line].style.display = "none" ;
    document.getElementsByClassName('default-center-side')[nth_of_line].style.display = "none" ;
    document.getElementsByClassName('default-right-side')[nth_of_line].style.display = "none" ;
    document.getElementsByClassName('edit-left-side')[nth_of_line].style.display = "block" ;
    document.getElementsByClassName('edit-center-side')[nth_of_line].style.display = "block" ;
    document.getElementsByClassName('edit-right-side')[nth_of_line].style.display = "block" ;
}
function goToDefaultDetails(event, nth_of_line){
    event.preventDefault();
    document.getElementsByClassName('edit-left-side')[nth_of_line].style.display = "none" ;
    document.getElementsByClassName('edit-center-side')[nth_of_line].style.display = "none" ;
    document.getElementsByClassName('edit-right-side')[nth_of_line].style.display = "none" ;
    document.getElementsByClassName('default-left-side')[nth_of_line].style.display = "block" ;
    document.getElementsByClassName('default-center-side')[nth_of_line].style.display = "block" ;
    document.getElementsByClassName('default-right-side')[nth_of_line].style.display = "block" ;
}
function changeContainers(event, container_name) {
    let i, container_content, details_tab_buttons;
    container_content = document.getElementsByClassName("container-details-main");
    for (i = 0; i < container_content.length; i++) {
        container_content[i].style.display = "none";
    }
    details_tab_buttons = document.getElementsByClassName("details-tab");
    for (i = 0; i < details_tab_buttons.length; i++) {
        details_tab_buttons[i].className = details_tab_buttons[i].className.replace("active", "");
    }
    document.getElementById(container_name).style.display = "block";
    event.currentTarget.className += "active";
}

let name = document.getElementById('editDetailsForm-name');
let email = document.getElementById('editDetailsForm-email');
let group = document.getElementById('editDetailsForm-group');
let year = document.getElementById('editDetailsForm-year');
let student_description = document.getElementById('editDetailsForm-student_description');
let password = document.getElementById('editPasswordForm-password');
let new_password = document.getElementById('editPasswordForm-new_password');
let confirm_new_password = document.getElementById('editPasswordForm-confirm_new_password');
let name_submit_button = document.getElementsByClassName('submit-button')[0];
let email_submit_button = document.getElementsByClassName('submit-button')[1];
let group_submit_button = document.getElementById('editDetailsForm-submitGroup');
let year_submit_button = document.getElementById('editDetailsForm-submitYear');
let student_description_submit_button = document.getElementById('editDetailsForm-submitStudentDescription');
let password_submit_button = document.getElementsByClassName('submit-change-password')[0];

let line_input_requirements = document.getElementsByClassName('line-input-requirements')[0];
let line_input_requirements_password = document.getElementsByClassName('line-input-requirements')[1];

let empty_name_requirement = document.querySelectorAll('.input-requirements span:nth-of-type(1)')[0];
let empty_email_requirement = document.querySelectorAll('.input-requirements span:nth-of-type(2)')[0];
let max_length_name_requirement = document.querySelectorAll('.input-requirements span:nth-of-type(3)')[0];
let just_letters_name_requirement = document.querySelectorAll('.input-requirements span:nth-of-type(4)')[0];
let two_words_name_requirement = document.querySelectorAll('.input-requirements span:nth-of-type(5)')[0];
let max_length_email_requirement = document.querySelectorAll('.input-requirements span:nth-of-type(6)')[0];

let empty_password_requirement = document.querySelectorAll('.input-requirements span:nth-of-type(1)')[1];
let empty_new_password_requirement = document.querySelectorAll('.input-requirements span:nth-of-type(2)')[1];
let empty_confirm_new_password_requirement = document.querySelectorAll('.input-requirements span:nth-of-type(3)')[1];
let password_length_requirement = document.querySelectorAll('.input-requirements span:nth-of-type(4)')[1];
let new_password_length_requirement = document.querySelectorAll('.input-requirements span:nth-of-type(5)')[1];
let complexity_new_password_requirement = document.querySelectorAll('.input-requirements span:nth-of-type(6)')[1];
let confirm_new_password_length_requirement = document.querySelectorAll('.input-requirements span:nth-of-type(7)')[1];
let complexity_confirm_new_password_requirement = document.querySelectorAll('.input-requirements span:nth-of-type(8)')[0];

let name_errors_flag = true;
let email_errors_flag = true;
let password_errors_flag = false;
let new_password_errors_flag = false;
let confirm_new_password_errors_flag = false;
let password_input = "";
let new_password_input = "";
let confirm_new_password_input = "";
let name_value = name.value;
let email_value = email.value;
let group_value;
let year_value;
let student_description_value;

group_value = group.value;
year_value = year.value;
student_description_value = student_description.value;

group_submit_button.disabled = true;
year_submit_button.disabled = true;
student_description_submit_button.disabled = true;

group_submit_button.style.color = "#ccc";
year_submit_button.style.color = "#ccc";
student_description_submit_button.style.color = "#ccc";

let array;
name_submit_button.disabled = true;
email_submit_button.disabled = true;
password_submit_button.disabled = true;
name_submit_button.style.color = "#ccc";
email_submit_button.style.color = "#ccc";
password_submit_button.style.backgroundColor = "#ccc";
line_input_requirements.style.display = "none";
line_input_requirements_password.style.display = "none";
line_input_requirements_password.style.height = "60px";

name.addEventListener('keyup', function () {
    name_errors_flag = checkName(this);
    if ( !name_errors_flag || !email_errors_flag)
        line_input_requirements.style.display = "block";
    else
        line_input_requirements.style.display = "none";
    if ( !email_errors_flag )
        line_input_requirements.style.height = "80px";
    else
        line_input_requirements.style.height = "40px";
    if ( name_errors_flag )
        line_input_requirements.style.height = "40px";
    submitButton(name_submit_button, this, name_value, name_errors_flag, name);
});

email.addEventListener('keyup', function () {
    email_errors_flag = checkEmail(this);
    if ( !name_errors_flag || !email_errors_flag)
        line_input_requirements.style.display = "block";
    else
        line_input_requirements.style.display = "none";
    if ( !name_errors_flag )
        line_input_requirements.style.height = "80px";
    else
        line_input_requirements.style.height = "40px";
    if ( email_errors_flag )
        line_input_requirements.style.height = "40px";
    submitButton(email_submit_button, this, email_value, email_errors_flag, email);
});


group.addEventListener('change', function () {
    submitButton(group_submit_button, this, group_value, true, group);
});

year.addEventListener('change', function () {
    submitButton(year_submit_button, this, year_value, true, year);
});

student_description.addEventListener('keyup', function() {
    if (this.value === ""){
        student_description_submit_button.disabled = true;
        student_description_submit_button.style.color = "#ccc";
        this.classList.remove("is-valid");
        this.classList.add("is-invalid");
    }
    if (this.value.match(/[a-zA-Z]/g)) {
        submitButton(student_description_submit_button, this, student_description_value, true, student_description);
    }
});


password.addEventListener('keyup', function () {
    array = checkPassword(this);
    password_input = array[0];
    password_errors_flag = array[1];
    if ( !password_errors_flag || !new_password_errors_flag || !confirm_new_password_errors_flag ) {
        line_input_requirements_password.style.display = "block";
        line_input_requirements_password.style.height = "80px";
    }
    submitChangePasswordButton();
});

new_password.addEventListener('keyup', function () {
    array = checkNewPassword(this);
    new_password_input = array[0];
    new_password_errors_flag = array[1];
    if ( !password_errors_flag || !new_password_errors_flag || !confirm_new_password_errors_flag ) {
        line_input_requirements_password.style.display = "block";
        line_input_requirements_password.style.height = "80px";
    }
    submitChangePasswordButton();
});

confirm_new_password.addEventListener('keyup', function () {
    array = checkConfirmNewPassword(this);
    confirm_new_password_input = array[0];
    confirm_new_password_errors_flag = array[1];
    if ( !password_errors_flag || !new_password_errors_flag || !confirm_new_password_errors_flag) {
        line_input_requirements_password.style.display = "block";
        line_input_requirements_password.style.height = "80px";
    }
    submitChangePasswordButton()
});

function hasWhiteSpace(s) {
  return s.indexOf(' ') >= 0;
}

function checkName(input){

        if ( input.value.length > 40){
             max_length_name_requirement.style.display = 'block';
             max_length_name_requirement.classList.add('invalid');
             return false;
         }
         else
         {
             if ( input.value.length === 0 ){
                 max_length_name_requirement.style.display = 'none';
                 just_letters_name_requirement.style.display = 'none';
                 two_words_name_requirement.style.display = 'none';
                 empty_name_requirement.style.display = 'block';
                 empty_name_requirement.classList.add('invalid');
                 return false;
             }
             else
             {
                empty_name_requirement.style.display = 'none';
             }
             max_length_name_requirement.style.display = 'none';
         }

         if (input.value.match(/[^a-zA-Z ]/g)){
             just_letters_name_requirement.style.display = 'block';
             just_letters_name_requirement.classList.add('invalid');
             return false;
         }
         else
         {
             just_letters_name_requirement.style.display = 'none';
         }

         if (input.value.match(/[a-zA-Z]{3,20}[ ][a-zA-Z]{3,20}/g) || input.value.length === 0){
             two_words_name_requirement.style.display = 'none';
         }
         else
         {
             two_words_name_requirement.style.display = 'block';
             two_words_name_requirement.classList.add('invalid');
             return false;
         }
         return true;
}

function checkEmail(input){

         if ( input.value.length > 40){
             max_length_email_requirement.style.display = 'block';
             max_length_email_requirement.classList.add('invalid');
             return false;
         }
         else
         {
             if ( input.value.length === 0 ){
                 empty_email_requirement.style.display = 'block';
                 empty_email_requirement.classList.add('invalid');
                 return false;
             }
             else
             {
                empty_email_requirement.style.display = 'none';
             }
             max_length_email_requirement.style.display = 'none';
         }
         return true;
}

function checkPassword(input){

         if ( (input.value.length < 6 || input.value.length > 30 ) && input.value.length  !== 0 ){
             password_length_requirement.style.display = 'block';
             password_length_requirement.classList.add('invalid');
             password.classList.remove("is-valid");
             password.classList.add("is-invalid");
             return [input.value, false];
         }
         else
         {
             password_length_requirement.style.display = 'none';
             password.classList.remove("is-invalid");
             password.classList.add("is-valid");
         }
        return [input.value, true];
}

function checkNewPassword(input){

         if ( (input.value.length < 6 || input.value.length > 30) && input.value.length !== 0 ){
             new_password_length_requirement.style.display = 'block';
             new_password_length_requirement.classList.add('invalid');
             new_password.classList.remove('is-valid');
             new_password.classList.add('is-invalid');
             return [input.value, false];
         }
         else
         {
             new_password_length_requirement.style.display = 'none';
             new_password.classList.remove("is-invalid");
             new_password.classList.add("is-valid");
         }

         if ( input.value.match(/[a-z]/g) && input.value.match(/[A-Z]/g) && input.value.match(/[0-9]/g))
         {
             complexity_new_password_requirement.style.display = 'none';
             new_password.classList.remove('is-invalid');
             new_password.classList.add('is-valid');
         }
         else
         {
             complexity_new_password_requirement.style.display = 'block';
             complexity_new_password_requirement.classList.add('invalid');
             new_password.classList.remove('is-valid');
             new_password.classList.add('is-invalid');
             return [input.value, false];
         }
         return [input.value, true];
}

function checkConfirmNewPassword(input){

        if ( (input.value.length < 6 || input.value.length > 30) && input.value.length !== 0 ){
             confirm_new_password_length_requirement.style.display = 'block';
             confirm_new_password_length_requirement.classList.add('invalid');
             confirm_new_password.classList.remove('is-valid');
             confirm_new_password.classList.add('is-invalid');
             return [input.value, false];
         }
         else
         {
             confirm_new_password_length_requirement.style.display = 'none';
             confirm_new_password.classList.remove("is-invalid");
             confirm_new_password.classList.add("is-valid");
         }

         if ( input.value.match(/[a-z]/g) && input.value.match(/[A-Z]/g) && input.value.match(/[0-9]/g))
         {
             complexity_confirm_new_password_requirement.style.display = 'none';
             confirm_new_password.classList.remove('is-invalid');
             confirm_new_password.classList.add('is-valid');
         }
         else
         {
             complexity_confirm_new_password_requirement.style.display = 'block';
             complexity_confirm_new_password_requirement.classList.add('invalid');
             confirm_new_password.classList.remove('is-valid');
             confirm_new_password.classList.add('is-invalid');
             return [input.value, false];
         }
         return [input.value, true];
}

function submitButton(submit_button, input, value, flag, element){
    if ( input.value !== value && flag) {
        submit_button.disabled = false;
        submit_button.style.color = "limegreen";
        element.classList.remove('is-invalid');
        element.classList.add('is-valid');
    }
    else {
        submit_button.disabled = true;
        submit_button.style.color = "#ccc";
        element.classList.remove('is-valid');
        element.classList.add('is-invalid');
        if (input.value === value) {
            element.classList.remove('is-valid');
            element.classList.remove('is-invalid');
        }
    }
}

function submitChangePasswordButton(){
    if ( password_errors_flag && new_password_errors_flag && confirm_new_password_errors_flag) {
        line_input_requirements_password.style.display = "none";
        password_submit_button.disabled = false;
        password_submit_button.style.background = "#5cb85c";
    }
    else {
        password_submit_button.disabled = true;
        password_submit_button.style.background = "#ccc";
    }
}

/*
    ----------------------------------------------------------
    ------------------- VALIDARE FOCUSOUT --------------------
    ----------------------------------------------------------
                                                                */

$(document).ready(function(){

     $("#editPasswordForm-password").focusout(function(){
        if ( password_input.length === 0 ) {
            line_input_requirements_password.style.display = "block";
            empty_password_requirement.classList.add('invalid');
            empty_password_requirement.style.display = "block";
            this.classList.remove("is-valid");
            this.classList.add("is-invalid");
            password_errors_flag = false;
            submitChangePasswordButton()
        }
        else
        {
            empty_password_requirement.style.display = "none";
        }
    });

    $("#editPasswordForm-new_password").focusout(function(){
        if ( new_password_input.length === 0 ) {
            line_input_requirements_password.style.display = "block";
            empty_new_password_requirement.classList.add('invalid');
            empty_new_password_requirement.style.display = "block";
            this.classList.remove("is-valid");
            this.classList.add("is-invalid");
            new_password_errors_flag = false;
            submitChangePasswordButton()
        }
        else
        {
            empty_new_password_requirement.style.display = "none";
        }
    });

    $("#editPasswordForm-confirm_new_password").focusout(function(){
        if ( confirm_new_password_input.length === 0 ) {
            line_input_requirements_password.style.display = "block";
            empty_confirm_new_password_requirement.classList.add('invalid');
            empty_confirm_new_password_requirement.style.display = "block";
            this.classList.remove("is-valid");
            this.classList.add("is-invalid");
            confirm_new_password_errors_flag = false;
            submitChangePasswordButton()
        }
        else
        {
            empty_confirm_new_password_requirement.style.display = "none";
        }
    });

});

$('.first-eye').click(function () {
   if ($('#editPasswordForm-password').attr('type') === 'password'){
        $('#editPasswordForm-password').attr('type', 'text');
   }
   else
   {
        $('#editPasswordForm-password').attr('type', 'password');
   }
});

$('.second-eye').click(function () {
    if ($('#editPasswordForm-new_password').attr('type') === 'password'){
        $('#editPasswordForm-new_password').attr('type', 'text');
   }
   else
   {
        $('#editPasswordForm-new_password').attr('type', 'password');
   }
});

$('.third-eye').click(function () {
    if ($('#editPasswordForm-confirm_new_password').attr('type') === 'password'){
        $('#editPasswordForm-confirm_new_password').attr('type', 'text');
   }
   else
   {
        $('#editPasswordForm-confirm_new_password').attr('type', 'password');
   }
});


$("body").tooltip({ selector: '[data-toggle=tooltip]'});

let default_center_side_text_list = document.getElementsByClassName("default-center-side-text");
let element, element_text;
for( let i = 0 ; i < default_center_side_text_list.length ; i ++ ){
    element = default_center_side_text_list[i];
    if ( element.scrollHeight > 20 ){
        element_text = element.innerText;
        if ( $(window).width() > 450 )
        {
             element.innerText = element_text.substring(0, 25) + "...";
        }
        else
        {
            element.innerText = element_text.substring(0, 15) + "...";
        }
    }
}

$("#description-edit-button").click(function(){
    $("#details-label-line-description").css({"margin-top":30});
});

$("#description-cancel-button").click(function(){
    $("#details-label-line-description").css({"margin-top":5});
});

$("#description-edit-button-professor").click(function(){
    $("#details-label-line-description-professor").css({"margin-top":30});
});

$("#description-cancel-button-professor").click(function(){
    $("#details-label-line-description-professor").css({"margin-top":5});
});


$("#editDetailsForm-student_description").css({"text-align-last":"left"});
$("#editDetailsForm-professor_description").css({"text-align-last":"left"});