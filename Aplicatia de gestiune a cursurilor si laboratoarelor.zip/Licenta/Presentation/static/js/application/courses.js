$( document ).ready(function() {
    let third_line_height = $(".third-line-container").height();
    $(".second-line-container").height(third_line_height);
    $(".first-line-container").height(third_line_height);
    $("#main-container").height(third_line_height+200);
});