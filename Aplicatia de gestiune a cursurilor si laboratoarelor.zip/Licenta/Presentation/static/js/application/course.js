let nrQuestions;
let indexQuestion;
let courseExamUuid;
let lastExaminationButton;
let questions = [];
let questionCorrectAnswer;
let time;
let questionScore;
let totalScore = 0;
let userScore = 0;
let timerWasSet = false;
let lastCommentUUID;
const addCommentTextbox = $('#add-comment-textbox');
const showAddComment = $('#show-add-comment');

$(addCommentTextbox).val("");

$(showAddComment).click(function () {
    $('#add-comment').show(500);
    $(this).hide();
});

$('.fa-window-minimize').click(function () {
   $('#add-comment').hide(500);
   $('#show-add-comment').show();
});

$('#add-comment-button').click(function () {
    let question_text = $(addCommentTextbox).val().trim();
    if ( question_text !== "" && question_text.match(/[^ ]/g)) {
        sendQuestionText(question_text);
        $(addCommentTextbox).val("");
        $(addCommentTextbox).focus();
    }
});

$('')

function sendQuestionText(question_text){
    $.ajax({
        url: "/add_question_course",
        data: {question_text: question_text, course_uuid: course_uuid},
        dataType: "json",
        success: function (data) {
            let comment_html = `
                <div class="comment-container" data-id="${data["uuid"]}">
                    <div class="comment-title">
                        <span class="comment-creator-name">${data["author_fullname"]}</span>•
                        <span class="comment-date">${data["date"]}</span>
                    </div>
                    <div class="comment-text">
                        ${data["text"]}
                    </div>
                    <textarea class="edit-comment-textarea"></textarea>
                    <div class="comment-bottom">
            `;
            if ( data["author"] === true ) {
                comment_html += `
                    <button class="save-edits-comment-button comment-button">
                        <i class="fa fa-save comment-icon"></i>
                        Salveaza
                    </button>
                    <button class="cancel-edits-comment-button comment-button">
                        <i class="fa fa-undo comment-icon"></i>
                        Revocare
                    </button>
                    <button class="edit-comment-button comment-button">
                        <i class="fa fa-edit comment-icon"></i>
                        Modifica
                    </button>
                    <button class="delete-comment-button comment-button">
                        <i class="fa fa-times comment-icon"></i>
                        Sterge
                    </button>
                `;
            }
            comment_html += `</div></div>`;
            $(comment_html).insertAfter('#add-comment');
        }
    });
}

function deleteQuestion(uuid){
    const formData = new FormData();
    formData.append('uuid', uuid);

    return fetch('/delete_question', {
        method: 'DELETE',
        body: formData
    }).then($(`[data-id="${uuid}"`).remove())
}

$(document).on('click', '.delete-comment-button', function(e) {
     let uuid = $(this).closest(".comment-container").attr('data-id');
     deleteQuestion(uuid).then(r => console.log(r));
});

$(document).on('click', ".open-examination", function(){
    lastExaminationButton = this;
    const coursePdfUuid = this.getAttribute('data-uuid');
    const durationElement = document.querySelector('.course-examination-details .duration');
    const accessDateElement = document.querySelector('.course-examination-details .access-date');
    const extraDetailsElement = document.querySelector('.course-examination-details .extra-details');
    fetch(`/get_course_exam_data/${coursePdfUuid}`)
    .then(response => response.json())
    .then(data => {
        courseExamUuid = data['uuid']
        durationElement.innerHTML = data['duration_minutes']
        accessDateElement.innerHTML = data['start_date']
        extraDetailsElement.innerHTML = data['details']
    });
    $("#examination-modal").css("display", "flex");
});

$(document).on('click', ".not-passed-examination", function(){
    const coursePdfUuid = this.getAttribute('data-uuid');
    const resultElement = document.querySelector('.text-result span');
    fetch(`get_course_exam_result_grade/${coursePdfUuid}`)
    .then(response => response.json())
    .then(data => {
        resultElement.innerHTML = data['grade']
    });
    $("#after-examination-modal").css("display", "flex");
});

$("#after-examination-modal button").click(function(){
     $(this).parent().parent().css("display", "none");
});

$(document).on('click', ".passed-examination", function(){
    const coursePdfUuid = this.getAttribute('data-uuid');
    const resultElement = document.querySelector('.text-result span');
    fetch(`get_course_exam_result_grade/${coursePdfUuid}`)
    .then(response => response.json())
    .then(data => {
        resultElement.innerHTML = data['grade']
    });
    $("#after-examination-modal").css("display", "flex");
});

$(document).on('keyup','.edit-comment-textarea',function(e){
    let save_button = $(this).next('.comment-bottom').children().eq(0);
    let comment_text = $(this).prev('.comment-text');
    if ( comment_text.text() !== $(this).val() && $(this).val() !== "" && $(this).val().length < 500 && $(this).val().trim().length !== 0){
        save_button.css('color','limegreen');
        save_button.prop('disabled', false);
    }
    else{
        save_button.css('color','darkgray');
        save_button.prop('disabled', true);
    }
});

$(document).on('click', '.cancel-edits-comment-button', function(e) {
    let textarea = $(this).parent().prev('.edit-comment-textarea');
    let comment_text = textarea.prev('.comment-text');
    let save_button = $(this).prev('.save-edits-comment-button');
    let modify_button = $(this).next('.edit-comment-button');
    textarea.hide();
    $(this).hide();
    save_button.hide();
    modify_button.show();
    comment_text.show();
});

$(document).on('click', '.save-edits-comment-button', function(e) {
    let textarea = $(this).parent().prev('.edit-comment-textarea');
    let cancel_button = $(this).next('.cancel-edits-comment-button');
    let modify_button = cancel_button.next('.edit-comment-button');
    let comment_text = textarea.prev('.comment-text');
    let question_id = $(this).parent().parent().attr('id');
    $(this).hide();
    textarea.hide();
    cancel_button.hide();
    lastCommentUUID = $(this).closest(".comment-container").attr('data-id');
    editQuestion(question_id, textarea.val());
    modify_button.show();
    comment_text.show();
});

$(".container-buttons button:last-child").click(function(){
    $(this).parent().parent().parent().parent().css("display", "none");
});

$(".container-buttons button:first-child").click(function(){
    $(this).parent().parent().parent().html("");
    startTest();
});

function formatTime(time){
    return new Date(time * 1000).toISOString().substr(11, 8)
}

$(document).on('click', '.edit-comment-button', function(e) {
    let textarea = $(this).parent().prev('.edit-comment-textarea');
    let comment_text = textarea.prev('.comment-text');
    let cancel_button = $(this).prev('.cancel-edits-comment-button');
    let save_button = cancel_button.prev('.save-edits-comment-button');
    comment_text.hide();
    $(this).hide();
    textarea.text(comment_text.text().trim());
    save_button.prop('disabled', true);
    save_button.css('color','darkgray');
    save_button.show();
    cancel_button.show();
    textarea.show();
});

function editQuestion(question_id, new_text){
    console.log(lastCommentUUID);
    $.ajax({
        url: "/edit_comment",
        data: {uuid: lastCommentUUID, new_text: new_text},
        dataType: "json",
        success: function (data) {
            console.log(data);
            $(`[data-id="${lastCommentUUID}"`).children().eq(1).replaceWith("<div class=\"comment-text\">" + data.new_text +"</div>");
            $(`[data-id="${lastCommentUUID}"`).children().eq(0).replaceWith("<div class=\"comment-title\"><span class=\"comment-creator-name\">" + data.author_name +
                "</span> • <span class=\"comment-date\"> " + data.comment_date +
                "</span><span class=\"edited-date\" data-toggle=\"tooltip\" title=\"" + data.edit_date + "\">(editat)</span></div>")
        }
    });
}

function showQuestion(){
    questionScore = questions[indexQuestion]['score'];

    if(timerWasSet === false) {
        time = parseInt(questions[indexQuestion]['time']) * 60;

        setInterval(function() {
        time -= 1;

        if (time===0)
        {
            $("#examination-modal").css("display", "none");
            if (userScore < totalScore / 2)
            {
                Swal.fire({
                    text: `Examenul s-a terminat, ai obtinut punctajul de ${userScore} puncte din ${totalScore}!`,
                    type: 'error'
                });
                $(lastExaminationButton).addClass('not-passed-examination');
                $(lastExaminationButton).removeClass('open-examination');
            }
            else
            {
                Swal.fire({
                    text: `Examenul s-a terminat, ai obtinut punctajul de ${userScore} puncte din ${totalScore}!`,
                    type: 'success'
                });
                $(lastExaminationButton).addClass('passed-examination');
                $(lastExaminationButton).removeClass('open-examination');
            }
            postData('send_exam_results', {
                'course_exam_uuid': courseExamUuid,
                'score': userScore
            })
            .then(data => {
                console.log(data);
            });
        }

        $(".timer").html(formatTime(time));
    }, 1000)

        timerWasSet = true;
    }

    let modalHTML = `
        <div class="question-timer">
            <div class="question">
                ${indexQuestion + 1}. ${questions[indexQuestion]['name']}
            </div>
            <div class="timer">
                ${formatTime(time)}
            </div>
        </div>
    `;

    for(const answer of questions[indexQuestion]['answers'])
    {
        if (answer['is_correct'] === true)
            questionCorrectAnswer = answer['name'];

        modalHTML += `
            <div class="answer">
                <input type="radio" name="answer"> ${answer['name']}
            </div>
        `;
    }

    modalHTML += `
        <div class="container-question-buttons">
            <button id="nextButton">Next</button>
        </div>
    `;

    $("#examination-modal .modal-content").html(
        modalHTML
    );
}

function startTest(){
    indexQuestion = 0;
    fetch(`/get_exam_questions_answers/${courseExamUuid}`)
    .then(response => response.json())
    .then(data => {
        questions = data;
        questions.forEach(function(question){
            totalScore += question.score;
        })
        nrQuestions = questions.length;
        showQuestion();
    });
}

$(document).on('click', '#nextButton', function() {
    $('.answer input[type="radio"]:checked').each(function() {
        let answer = $(this).parent().text().replace(/ /g,'');
        answer = answer.substring(0, answer.length - 1).trim();
        if (questionCorrectAnswer === answer)
            userScore += questionScore;
    });
    indexQuestion++;
    if(indexQuestion !== nrQuestions)
        showQuestion();
    else{
        $("#examination-modal").css("display", "none");
        if (userScore < totalScore / 2)
        {
            Swal.fire({
                text: `Examenul s-a terminat, ai obtinut punctajul de ${userScore} puncte din ${totalScore}!`,
                type: 'error'
            });
            $(lastExaminationButton).addClass('not-passed-examination');
            $(lastExaminationButton).removeClass('open-examination');
        }
        else
        {
            Swal.fire({
                text: `Examenul s-a terminat, ai obtinut punctajul de ${userScore} puncte din ${totalScore}!`,
                type: 'success'
            });
            $(lastExaminationButton).addClass('passed-examination');
            $(lastExaminationButton).removeClass('open-examination');
        }
        postData('send_exam_results', {
            'course_exam_uuid': courseExamUuid,
            'score': userScore
        })
        .then(data => {
            console.log(data);
        });
    }
});

async function postData(url = '', data = {}) {
  // Default options are marked with *
  const response = await fetch(url, {
    method: 'POST', // *GET, POST, PUT, DELETE, etc.
    mode: 'cors', // no-cors, *cors, same-origin
    cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached
    credentials: 'same-origin', // include, *same-origin, omit
    headers: {
      'Content-Type': 'application/json'
      // 'Content-Type': 'application/x-www-form-urlencoded',
    },
    redirect: 'follow', // manual, *follow, error
    referrerPolicy: 'no-referrer', // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
    body: JSON.stringify(data) // body data type must match "Content-Type" header
  });
  return response.json(); // parses JSON response into native JavaScript objects
}