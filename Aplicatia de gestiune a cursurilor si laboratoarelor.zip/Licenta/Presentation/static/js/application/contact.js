 /*
    ----------------------------------------------------------
    ------- FUNCTII VALIDARE REAL-TIME CLIENT SIDE  ----------
    ----------------------------------------------------------
                                                                */

function checkDescription(input){

        if ( input.value.length > 300){
             document.querySelectorAll('.input-requirements')[0].style.display = 'block';
             submit_button.style.marginTop = 0;
             let validation = document.querySelectorAll('.input-requirements span:nth-of-type(3)')[0];
             validation.style.display = 'block';
             validation.classList.add('invalid');
             description.classList.remove('is-valid');
             description.classList.add('is-invalid');
             return [input.value, false];
         }
         else
         {
             document.querySelectorAll('.input-requirements')[0].style.display = 'none';
             submit_button.style.marginTop = '15px';
             let validation = document.querySelectorAll('.input-requirements span:nth-of-type(3)')[0];
             validation.style.display = 'none';
             description.classList.remove('is-invalid');
             description.classList.add('is-valid');
         }

          if (!input.value.replace(/\s/g, '').length) {
             document.querySelectorAll('.input-requirements')[0].style.display = 'block';
             submit_button.style.marginTop = 0;
             let validation = document.querySelectorAll('.input-requirements span:nth-of-type(2)')[0];
             validation.style.display = 'block';
             validation.classList.add('invalid');
             description.classList.remove('is-valid');
             description.classList.add('is-invalid');
             return [input.value, false];
         }
         else
         {
             document.querySelectorAll('.input-requirements')[0].style.display = 'none';
             submit_button.style.marginTop = '15px';
             let validation = document.querySelectorAll('.input-requirements span:nth-of-type(2)')[0];
             validation.style.display = 'none';
             description.classList.remove('is-invalid');
             description.classList.add('is-valid');
         }

         if ( input.value.length === 0 )
         {
             document.querySelectorAll('.input-requirements')[0].style.display = 'block';
             submit_button.style.marginTop = 0;
             return [input.value, false];
         }

         document.querySelectorAll('.input-requirements')[0].style.display = 'none';
         submit_button.style.marginTop = '15px';
         return [input.value, true];
}


function submitButton(){
    if ( flagDescription ) {
        submit_button.disabled = false;
        submit_button.style.background = "#5cb85c";
    }
    else {
        submit_button.disabled = true;
        submit_button.style.background = "#ccc";
    }
}



let description = document.getElementById('text');
let submit_button = document.getElementById('submit');
description.value = "";
let description_input = "";
let flagDescription = false;
let array;
submit_button.style.background = "#ccc";
submit_button.disabled = true;


description.addEventListener('keyup', function(){
   array = checkDescription(this);
   description_input = array[0];
   flagDescription = array[1];
   submitButton();
});

$(document).ready(function() {

    $("#text").focusout(function () {
        if (description_input.length === 0) {
            document.querySelectorAll('.input-requirements')[0].style.display = 'block';
            submit_button.style.marginTop = 0;
            let validation_message_2 = document.querySelectorAll('.input-requirements span:nth-of-type(2)')[0];
            validation_message_2.style.display = 'none';
            let validation_message_1 = document.querySelectorAll('.input-requirements span:nth-of-type(1)')[0];
            validation_message_1.classList.add('invalid');
            validation_message_1.style.display = "block";
            this.classList.remove("is-valid");
            this.classList.add("is-invalid");
        }
        else {
            document.querySelectorAll('.input-requirements')[0].style.display = 'none';
            submit_button.style.marginTop = '15px';
            let validation_message_1 = document.querySelectorAll('.input-requirements span:nth-of-type(1)')[0];
            validation_message_1.style.display = "none";
        }

    });
});

let container_details_width = document.getElementsByClassName('container-contact')[0].offsetWidth;
document.getElementsByClassName('application-toastr')[0].style.width = container_details_width.toString() + "px";
$('.sidebar-arrow').click(function() {
    let container_details_width = document.getElementsByClassName('container-contact')[0].offsetWidth;
    document.getElementsByClassName('application-toastr')[0].style.width = container_details_width.toString() + "px";
});