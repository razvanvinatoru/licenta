$('#add-comment-textbox').val("");

$('#show-add-comment').click(function () {
    $('#add-comment').show(500);
    $(this).hide();
});

$('.fa-window-minimize').click(function () {
   $('#add-comment').hide(500);
   $('#show-add-comment').show();
});

$('#add-comment-button').click(function () {
    let question_text = $('#add-comment-textbox').val();
    if ( question_text !== "" && question_text.match(/[^ ]/g)) {
        sendQuestionText(question_text);
        $('#add-comment-textbox').val('');
        $('#add-comment-textbox').focus();
    }
});

function sendQuestionText(question_text){
    $.ajax({
        url: "/add_question_laboratory",
        data: {question_text: question_text, laboratory_uuid: laboratory_uuid},
        dataType: "json",
        success: function (data) {

            let comment_html = "<div class=\"comment-container\">";
            comment_html += "<div class=\"comment-title\">";
            comment_html += "<span class=\"comment-creator-name\">" + data["author_fullname"];
            comment_html += "</span> • <span class=\"comment-date\"> " + data["date"] + "</span>";
            comment_html += "</div>";
            comment_html += "<div class=\"comment-text\">";
            comment_html += data["text"];
            comment_html += "</div>";
            comment_html += "<div class=\"edit-comment-textarea\" contenteditable=\"true\"></div>";
            comment_html += "<div class=\"comment-bottom\">";
            if ( data["author"] === true ) {
                comment_html += "<button class=\"save-edits-comment-button comment-button\"><i class=\"fa fa-save comment-icon\"></i> Salveaza</button>";
                comment_html += "<button class=\"cancel-edits-comment-button comment-button\"><i class=\"fa fa-undo comment-icon\"></i> Revocare</button>";
                comment_html += "<button class=\"edit-comment-button comment-button\"><i class=\"fa fa-edit comment-icon\"></i> Modifica</button>";
                comment_html += "<button class=\"delete-comment-button comment-button\"><i class=\"fa fa-times comment-icon\"></i>Sterge</button>";
            }
            comment_html += "</div></div>";
            $(comment_html).insertAfter('#add-comment');
        }
    });
}
$('#add-homework').on('click', function() {
    $('#homework-input').trigger('click');
});
$('#homework-input').on( 'change', function() {
   let myfile= $( this ).val();
   let ext = myfile.split('.').pop();
   if(ext !== "zip") {
      alert("E permisa adaugarea doar de arhiva .zip");
   }
});