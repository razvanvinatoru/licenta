from Presentation.Server import app
from Data.Utils.Generators import (
    generate_courses,
    generate_laboratories,
    generate_professors,
    generate_courses_pdfs,
    generate_laboratories_pdfs,
    generate_laboratories_homeworks,
    generate_courses_exams,
    generate_course_exam_questions,
    generate_course_exam_answers,
    modify_python_course,
    clear_db
)
from flask import redirect, url_for, render_template


@app.route('/')
def homepage():
    return redirect(url_for('home'))


@app.route('/index')
def index():
    return redirect(url_for('home'))


@app.route('/home')
def home():
    # clear_db()
    # generate_professors()
    # generate_courses()
    # generate_laboratories()
    # generate_courses_pdfs()
    # generate_courses_exams()
    # generate_course_exam_questions()
    # generate_course_exam_answers()
    # generate_laboratories_pdfs()
    # generate_laboratories_homeworks()
    # modify_python_course()

    return render_template("home/home.html")
