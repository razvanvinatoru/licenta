import os
from flask import Blueprint, request, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from Bussiness.Services.LaboratoryService import LaboratoryService
from Bussiness.Services.LaboratoryPdfService import LaboratoryPdfService
from Bussiness.Services.LaboratoryHomeworkService import LaboratoryHomeworkService
from Bussiness.Services.HardcodedProfessorService import HardcodedProfessorService
from Bussiness.Services.QuestionLaboratoryService import QuestionLaboratoryService
from Bussiness.Services.LaboratoryHomeworkSentService import LaboratoryHomeworkSentService
from Data.Utils.CourseUtils import return_courses_json, return_laboratories_json
from Data.Utils.DateUtils import get_datetime_now
from werkzeug.utils import secure_filename
from Presentation.Server import app


laboratory_bp = Blueprint('laboratory_bp', __name__)
_hardcoded_professor_service = HardcodedProfessorService()
_question_laboratory_service = QuestionLaboratoryService()
_laboratory_homework_service = LaboratoryHomeworkService()
_laboratory_homework_sent_service = LaboratoryHomeworkSentService()
_laboratory_service = LaboratoryService()
_laboratory_pdf_service = LaboratoryPdfService()


@laboratory_bp.route('/app/laboratory/<laboratory_uuid>', methods=["POST", "GET"])
@login_required
def laboratory(laboratory_uuid):
    _courses_json = return_courses_json()
    _laboratories_json = return_laboratories_json()

    def allowed_file(filename_):
        allowed_extensions = ('rar', 'zip')
        return '.' in filename_ and filename_.rsplit('.', 1)[1].lower() in allowed_extensions

    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file was found in request')
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            laboratory_homework = _laboratory_homework_service.get_by_laboratory_uuid_and_name(
                laboratory_uuid,
                request.form['homework-name'].replace('_', ' ',).capitalize()
            )
            _laboratory_homework_sent_service.add(**{
                'student_uuid': current_user.uuid,
                'laboratory_homework_uuid': laboratory_homework.uuid,
                'path': filename,
                'date': get_datetime_now()
            })
            flash("Arhiva a fost incarcata cu succes!", 'success')

    _laboratory = _laboratory_service.get_laboratory_by_uuid(laboratory_uuid)

    _questions = _question_laboratory_service.get_by_laboratory_uuid(laboratory_uuid)

    professor_laboratories = _laboratory_service.get_professor_laboratories_by_laboratory_uuid(laboratory_uuid)

    _hardcoded_professors = [
        _hardcoded_professor_service.get_first_professor_by_uuid(professor_laboratory.id_professor).full_name
        for professor_laboratory in professor_laboratories
    ]

    questions = list()
    question = dict()

    for _question in _questions:
        _user = _user_service.get_first_user_by_uuid(_question.uuid_user)

        question["author_fullname"] = _user.lastname + " " + _user.firstname
        question["date"] = format_comment_date(_question.date)
        question["text"] = _question.text
        if current_user.uuid == _question.uuid_user:
            question["author"] = True
        else:
            question["author"] = False
        questions.append(question)

    laboratory_pdfs = _laboratory_pdf_service.get_by_laboratory_uuid(laboratory_uuid_=laboratory_uuid)
    laboratory_homeworks = _laboratory_homework_service.get_by_laboratory_uuid(laboratory_uuid_=laboratory_uuid)

    laboratory_homeworks_sent = {}
    for laboratory_homework in laboratory_homeworks:
        print(laboratory_homework.uuid, current_user.uuid, end=100*"*"+'\n')
        laboratory_homeworks_sent[laboratory_homework.uuid] = \
            _laboratory_homework_sent_service.get_by_laboratory_homework_uuid_and_student_uuid(
                laboratory_homework.uuid,
                current_user.uuid
            )
    print(laboratory_homeworks_sent)

    return render_template("application/laboratory.html",
                           laboratory_uuid=laboratory_uuid,
                           laboratory_name=_laboratory.name,
                           courses_json=_courses_json,
                           laboratories_json=_laboratories_json,
                           questions=questions,
                           professors=_hardcoded_professors,
                           user_uuid=current_user.uuid,
                           laboratory_pdfs=laboratory_pdfs,
                           laboratory_homeworks=laboratory_homeworks,
                           laboratory_homeworks_sent=laboratory_homeworks_sent)


@laboratory_bp.route('/app/laboratory/<laboratory_uuid>/<pdf_name>')
@login_required
def laboratory_pdf(laboratory_uuid, pdf_name):
    _courses_json = return_courses_json()
    _laboratories_json = return_laboratories_json()

    _pdf_name = pdf_name.split(".pdf")[0]

    return render_template("application/laboratory_pdf.html", laboratory_uuid=laboratory_uuid,
                           pdf_name=pdf_name,
                           _pdf_name=_pdf_name,
                           courses_json=_courses_json, laboratories_json=_laboratories_json)


@laboratory_bp.route('/app/laboratory/homework/<laboratory_uuid>/<pdf_name>')
@login_required
def laboratory_homework_pdf(laboratory_uuid, pdf_name):
    _courses_json = return_courses_json()
    _laboratories_json = return_laboratories_json()

    _pdf_name = pdf_name.split(".pdf")[0]

    return render_template("application/laboratory_homework_pdf.html", laboratory_uuid=laboratory_uuid,
                           pdf_name=pdf_name,
                           _pdf_name=_pdf_name,
                           courses_json=_courses_json, laboratories_json=_laboratories_json)
