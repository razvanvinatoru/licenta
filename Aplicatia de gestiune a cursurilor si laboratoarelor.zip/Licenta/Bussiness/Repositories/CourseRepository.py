import uuid
from Presentation.Server import db
from Data.Domain.Course import Course
from Data.Domain.ProfessorCourse import ProfessorCourse
from Data.Domain.HardcodedProfessor import HardcodedProfessor


class CourseRepository:
    db_context = db.session

    @staticmethod
    def get_all_courses():
        return Course.query.all()

    @staticmethod
    def get_course_by_uuid(_uuid):
        try:
            return Course.query.filter_by(uuid=_uuid).first()
        except Exception as exception:
            print("get_course_by_uuid returned errors: {}".format(exception))

    @staticmethod
    def get_professor_courses_by_course_uuid(_course_uuid):
        try:
            return ProfessorCourse.query.filter_by(id_course=_course_uuid).all()
        except Exception as exception:
            print("get_professors_by_course_uuid returned errors: {}".format(exception))

    def add(self, _name, _description, _year, _semester, _hardcoded_professors):
        try:
            course = Course(uuid=str(uuid.uuid4()), name=_name,
                            description=_description, year=_year, semester=_semester)
            self.db_context.add(course)
            self.db_context.commit()
            self.db_context.flush()

            for professor in _hardcoded_professors:
                professor = HardcodedProfessor.query.filter_by(full_name=professor["nume"]).first()
                professor_course = ProfessorCourse(id_course=course.uuid, id_professor=professor.uuid)
                self.db_context.add(professor_course)
                self.db_context.commit()

        except Exception as exception:
            print("add_course returned errors: {}".format(exception))

    def update(self, uuid_, **kwargs):
        course = self.db_context.query(Course).filter(Course.uuid == uuid_).first()
        if 'name' in kwargs:
            course.name = kwargs['name']
        if 'description' in kwargs:
            course.description = kwargs['description']
        self.db_context.commit()

    @staticmethod
    def delete_all_courses():
        try:
            Course.query.delete()
        except Exception as exception:
            print("delete_all_courses returned errors: {}".format(exception))

    def delete_all_professor_courses(self):
        try:
            ProfessorCourse.query.delete()
            self.db_context.commit()
        except Exception as exception:
            print("delete_all_professor_course returned errors: {}".format(exception))

