import uuid
from Bussiness.Repositories.IRepository import IRepository
from Data.Domain.ContactMessage import ContactMessage


class ContactMessageRepository(IRepository):
    def __init__(self):
        super().__init__()

    def add(self, **kwargs):
        contact_message = ContactMessage(
            uuid=str(uuid.uuid4()),
            email_reviewer=kwargs['email_reviewer'],
            text=kwargs['text'],
            message_date=kwargs['message_date']
        )
        self.db_context.add(contact_message)
        self.db_context.commit()

    def get_by_uuid(self, uuid_):
        return self.db_context.query(ContactMessage).filter(ContactMessage.uuid == uuid_).first()

    def get_all(self):
        return self.db_context.query(ContactMessage).all()

    def count(self):
        return self.db_context.query(ContactMessage).count()

    def delete_all(self):
        return self.db_context.query(ContactMessage).delete()

    def update(self, id_, **kwargs):
        pass

    def delete_by_uuid(self, id_):
        self.db_context.query(ContactMessage).filter(ContactMessage.uuid == id_).delete()
        self.db_context.commit()
