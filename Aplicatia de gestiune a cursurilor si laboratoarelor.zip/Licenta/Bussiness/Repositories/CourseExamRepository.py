import uuid
from Bussiness.Repositories.IRepository import IRepository
from Data.Domain.CourseExam import CourseExam


class CourseExamRepository(IRepository):
    def __init__(self):
        super().__init__()

    def add(self, **kwargs):
        course_exam = CourseExam(
            uuid=str(uuid.uuid4()),
            course_pdf_uuid=kwargs['course_pdf_uuid'],
            duration_minutes=kwargs['duration_minutes'],
            start_date=kwargs['start_date'],
            details=kwargs['details']
        )
        self.db_context.add(course_exam)
        self.db_context.commit()

    def get_by_uuid(self, uuid_):
        return self.db_context.query(CourseExam).filter(CourseExam.uuid == uuid_).first()

    def get_by_course_pdf_uuid(self, course_pdf_uuid_):
        return self.db_context.query(CourseExam).filter(CourseExam.course_pdf_uuid == course_pdf_uuid_).first()

    def get_all(self):
        return self.db_context.query(CourseExam).all()

    def count(self):
        return self.db_context.query(CourseExam).count()

    def delete_all(self):
        return self.db_context.query(CourseExam).delete()

    def update(self, id_, **kwargs):
        pass

    def delete_by_uuid(self, id_):
        self.db_context.query(CourseExam).filter(CourseExam.uuid == id_).delete()
        self.db_context.commit()
