import uuid
from Presentation.Server import db
from Data.Domain.Laboratory import Laboratory
from Data.Domain.HardcodedProfessor import HardcodedProfessor
from Data.Domain.ProfessorLaboratory import ProfessorLab


class LaboratoryRepository:
    db_context = db.session

    @staticmethod
    def get_all_laboratories():
        return Laboratory.query.all()

    @staticmethod
    def get_laboratory_by_uuid(_uuid):
        return Laboratory.query.filter_by(uuid=_uuid).first()

    @staticmethod
    def get_professor_laboratories_by_laboratory_uuid(_laboratory_uuid):
        try:
            return ProfessorLab.query.filter_by(id_laboratory=_laboratory_uuid).all()
        except Exception as exception:
            print("get_professor_courses_by_laboratory_uuid returned errors: {}".format(exception))

    def add_laboratory(self, _name, _description, _year, _semester, _hardcoded_professors):
        try:
            laboratory = Laboratory(uuid=str(uuid.uuid4()), name=_name,
                                    description=_description, year=_year, semester=_semester)
            self.db_context.add(laboratory)
            self.db_context.commit()
            self.db_context.flush()

            for professor in _hardcoded_professors:
                professor = HardcodedProfessor.query.filter_by(full_name=professor["nume"]).first()
                professor_lab = ProfessorLab(id_laboratory=laboratory.uuid,
                                             id_professor=professor.uuid)
                self.db_context.add(professor_lab)
                self.db_context.commit()
        except Exception as exception:
            print("add_laboratories returned errors: {}".format(exception))

    @staticmethod
    def delete_all_laboratories():
        try:
            Laboratory.query.delete()
        except Exception as exception:
            print("delete_all_laboratories returned errors: {}".format(exception))

    @staticmethod
    def delete_all_professor_laboratories():
        try:
            ProfessorLab.query.delete()
        except Exception as exception:
            print("delete_all_professor_laboratories returned errors: {}".format(exception))

