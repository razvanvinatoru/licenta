import uuid
from Presentation.Server import db
from Data.Domain.PendingAccount import PendingAccounts


class PendingAccountRepository:
    db_context = db.session

    @staticmethod
    def get_all_pending_accounts():
        return PendingAccounts.query.all()

    @staticmethod
    def get_first_pending_acc_by_token(_token):
        return PendingAccounts.query.filter_by(token=_token).first()

    def add_pending_account(self, _lastname, _firstname, _email, _password, _token,
                            _type_user,
                            _register_date):
        try:
            pending_acc = PendingAccounts(
                uuid=str(uuid.uuid4()),
                lastname=_lastname,
                firstname=_firstname,
                email=_email,
                password=_password,
                token=_token,
                type_user=_type_user,
                register_date=_register_date
            )
            self.db_context.add(pending_acc)
            self.db_context.commit()
        except:
            pass

    def delete_pending_account(self, _id):
        try:
            PendingAccounts.query.filter_by(id=_id).delete()
            self.db_context.commit()
        except:
            pass
