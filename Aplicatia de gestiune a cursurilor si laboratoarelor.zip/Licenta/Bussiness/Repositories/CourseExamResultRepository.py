import uuid
from Bussiness.Repositories.IRepository import IRepository
from Data.Domain.CourseExamResult import CourseExamResult


class CourseExamResultRepository(IRepository):
    def __init__(self):
        super().__init__()

    def add(self, **kwargs):
        course_exam_result = CourseExamResult(
            uuid=str(uuid.uuid4()),
            course_exam_uuid=kwargs['course_exam_uuid'],
            student_uuid=kwargs['student_uuid'],
            result=kwargs['result']
        )
        self.db_context.add(course_exam_result)
        self.db_context.commit()

    def get_by_uuid(self, uuid_):
        return self.db_context.query(CourseExamResult).filter(CourseExamResult.uuid == uuid_).first()

    def get_by_course_exam_uuid(self, course_exam_uuid):
        return self.db_context.query(CourseExamResult).filter(
            CourseExamResult.course_exam_uuid == course_exam_uuid).first()

    def get_by_student_uuid(self, student_uuid):
        return self.db_context.query(CourseExamResult).filter(
            CourseExamResult.student_uuid == student_uuid).first()

    def get_by_course_exam_and_student_uuid(self, course_exam_uuid, student_uuid):
        return self.db_context.query(CourseExamResult).filter(
            CourseExamResult.course_exam_uuid == course_exam_uuid).filter(
            CourseExamResult.student_uuid == student_uuid).first()

    def get_all(self):
        return self.db_context.query(CourseExamResult).all()

    def count(self):
        return self.db_context.query(CourseExamResult).count()

    def delete_all(self):
        return self.db_context.query(CourseExamResult).delete()

    def update(self, id_, **kwargs):
        pass

    def delete_by_uuid(self, id_):
        self.db_context.query(CourseExamResult).filter(CourseExamResult.uuid == id_).delete()
        self.db_context.commit()
