import uuid
from Bussiness.Repositories.IRepository import IRepository
from Data.Domain.LaboratoryHomework import LaboratoryHomework


class LaboratoryHomeworkRepository(IRepository):
    def __init__(self):
        super().__init__()

    def add(self, **kwargs):
        laboratory_homework = LaboratoryHomework(
            uuid=str(uuid.uuid4()),
            laboratory_uuid=kwargs['laboratory_uuid'],
            name=kwargs['name'],
            path=kwargs['path']
        )
        self.db_context.add(laboratory_homework)
        self.db_context.commit()

    def get_by_uuid(self, uuid_):
        return self.db_context.query(LaboratoryHomework).filter(LaboratoryHomework.uuid == uuid_).first()

    def get_by_laboratory_uuid(self, laboratory_uuid_):
        return self.db_context.query(LaboratoryHomework).filter(LaboratoryHomework.laboratory_uuid == laboratory_uuid_).all()

    def get_by_laboratory_uuid_and_name(self, laboratory_uuid_, name_):
        return self.db_context.query(LaboratoryHomework).filter(
            LaboratoryHomework.laboratory_uuid == laboratory_uuid_,
            LaboratoryHomework.name == name_
        ).first()

    def get_all(self):
        return self.db_context.query(LaboratoryHomework).all()

    def count(self):
        return self.db_context.query(LaboratoryHomework).count()

    def delete_all(self):
        return self.db_context.query(LaboratoryHomework).delete()

    def update(self, id_, **kwargs):
        laboratory_homework = self.db_context.query(LaboratoryHomework).filter(LaboratoryHomework.uuid == id_).first()
        if 'name' in kwargs:
            laboratory_homework.name = kwargs['name']
        if 'path' in kwargs:
            laboratory_homework.path = kwargs['path']
        self.db_context.commit()

    def delete_by_uuid(self, id_):
        self.db_context.query(LaboratoryHomework).filter(LaboratoryHomework.uuid == id_).delete()
        self.db_context.commit()
