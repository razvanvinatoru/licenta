import uuid
from Bussiness.Repositories.IRepository import IRepository
from Data.Domain.CourseExamQuestion import CourseExamQuestion


class CourseExamQuestionRepository(IRepository):
    def __init__(self):
        super().__init__()

    def add(self, **kwargs):
        course_exam_question = CourseExamQuestion(
            uuid=str(uuid.uuid4()),
            course_exam_uuid=kwargs['course_exam_uuid'],
            question=kwargs['question'],
            score=kwargs['score']
        )
        self.db_context.add(course_exam_question)
        self.db_context.commit()

    def get_by_uuid(self, uuid_):
        return self.db_context.query(CourseExamQuestion).filter(CourseExam.uuid == uuid_).first()

    def get_by_course_exam_uuid(self, course_exam_uuid_):
        return self.db_context.query(
            CourseExamQuestion).filter(CourseExamQuestion.course_exam_uuid == course_exam_uuid_).all()

    def get_all(self):
        return self.db_context.query(CourseExamQuestion).all()

    def count(self):
        return self.db_context.query(CourseExamQuestion).count()

    def delete_all(self):
        return self.db_context.query(CourseExamQuestion).delete()

    def update(self, id_, **kwargs):
        course_exam_question = self.db_context.query(CourseExamQuestion).filter(CourseExamQuestion.uuid == id_).first()
        if 'question' in kwargs:
            course_exam_question.question = kwargs['question']
        if 'score' in kwargs:
            course_exam_question.score = kwargs['score']
        self.db_context.commit()

    def delete_by_uuid(self, id_):
        self.db_context.query(CourseExamQuestion).filter(CourseExamQuestion.uuid == id_).delete()
        self.db_context.commit()
