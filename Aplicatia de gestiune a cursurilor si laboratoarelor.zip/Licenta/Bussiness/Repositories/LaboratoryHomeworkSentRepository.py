import uuid
from Bussiness.Repositories.IRepository import IRepository
from Data.Domain.LaboratoryHomeworkSent import LaboratoryHomeworkSent


class LaboratoryHomeworkSentRepository(IRepository):
    def __init__(self):
        super().__init__()

    def add(self, **kwargs):
        laboratory_homework_sent = LaboratoryHomeworkSent(
            uuid=str(uuid.uuid4()),
            laboratory_homework_uuid=kwargs['laboratory_homework_uuid'],
            student_uuid=kwargs['student_uuid'],
            path=kwargs['path'],
            date=kwargs['date']
        )
        self.db_context.add(laboratory_homework_sent)
        self.db_context.commit()

    def get_by_uuid(self, uuid_):
        return self.db_context.query(LaboratoryHomeworkSent).filter(LaboratoryHomeworkSent.uuid == uuid_).first()

    def get_by_laboratory_homework_uuid(self, laboratory_homework_uuid_):
        return self.db_context.query(LaboratoryHomeworkSent).filter(
            LaboratoryHomeworkSent.laboratory_homework_uuid == laboratory_homework_uuid_
        ).all()

    def get_by_laboratory_homework_uuid_and_student_uuid(self, laboratory_homework_uuid_, student_uuid_):
        return self.db_context.query(LaboratoryHomeworkSent).filter(
            LaboratoryHomeworkSent.laboratory_homework_uuid == laboratory_homework_uuid_,
            LaboratoryHomeworkSent.student_uuid == student_uuid_
        ).first()

    def get_all(self):
        return self.db_context.query(LaboratoryHomeworkSent).all()

    def count(self):
        return self.db_context.query(LaboratoryHomeworkSent).count()

    def delete_all(self):
        return self.db_context.query(LaboratoryHomeworkSent).delete()

    def update(self, id_, **kwargs):
        laboratory_homework_sent = self.db_context.query(LaboratoryHomeworkSent).filter(LaboratoryHomeworkSent.uuid == id_).first()
        if 'date' in kwargs:
            laboratory_homework_sent.date = kwargs['date']
        if 'path' in kwargs:
            laboratory_homework_sent.path = kwargs['path']
        self.db_context.commit()

    def delete_by_uuid(self, id_):
        self.db_context.query(LaboratoryHomeworkSent).filter(LaboratoryHomeworkSent.uuid == id_).delete()
        self.db_context.commit()
