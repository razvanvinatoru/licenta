from Presentation.Server import db
from Data.Domain.User import User


class UserRepository:
    db_context = db.session

    def add(self, **kwargs):
        user = User(
            uuid=str(uuid.uuid4()),
            lastname=kwargs['lastname'],
            firstname=kwargs['firstname'],
            email=kwargs['email'],
            password=kwargs['password']
        )
        self.db_context.add(course)
        self.db_context.commit()
        self.db_context.flush()
        return user.uuid

    @staticmethod
    def get_first_user_by_uuid(_uuid):
        return User.query.filter_by(uuid=_uuid).first()

    @staticmethod
    def get_first_user_by_email(_email):
        return User.query.filter_by(email=_email).first()

    @staticmethod
    def verify_if_email_exists(_email):
        user = User.query.filter_by(email=_email).first()

        if user:
            return True
        else:
            return False

    def update_password(self, _email, _password):
        user = User.query.filter_by(email=_email).first()
        user.password = _password
        self.db_context.commit()

    def update_lastname(self, _email, _lastname):
        user = User.query.filter_by(email=_email).first()
        user.lastname = _lastname
        self.db_context.commit()

    def update_firstname(self, _email, _firstname):
        user = User.query.filter_by(email=_email).first()
        user.firstname = _firstname
        self.db_context.commit()

    def update_email(self, _email, _new_email):
        user = User.query.filter_by(email=_email).first()
        user.email = _new_email
        self.db_context.commit()
