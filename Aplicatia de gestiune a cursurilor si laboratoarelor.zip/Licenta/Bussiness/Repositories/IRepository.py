from Presentation.Server import db
import abc


class IRepository(abc.ABC):
    @abc.abstractmethod
    def __init__(self):
        self.db_context = db.session

    @abc.abstractmethod
    def add(self, **kwargs):
        pass

    @abc.abstractmethod
    def get_by_uuid(self, id_):
        pass

    @abc.abstractmethod
    def get_all(self):
        pass

    @abc.abstractmethod
    def count(self):
        pass

    @abc.abstractmethod
    def update(self, id_, **kwargs):
        pass

    @abc.abstractmethod
    def delete_all(self):
        pass

    @abc.abstractmethod
    def delete_by_uuid(self, id_):
        pass
