import uuid
from Bussiness.Repositories.IRepository import IRepository
from Data.Domain.CoursePdf import CoursePdf


class CoursePdfRepository(IRepository):
    def __init__(self):
        super().__init__()

    def add(self, **kwargs):
        course_pdf = CoursePdf(
            uuid=str(uuid.uuid4()),
            course_uuid=kwargs['course_uuid'],
            name=kwargs['name'],
            path=kwargs['path']
        )
        self.db_context.add(course_pdf)
        self.db_context.commit()

    def get_by_uuid(self, uuid_):
        return self.db_context.query(CoursePdf).filter(CoursePdf.uuid == uuid_).first()

    def get_by_course_uuid(self, course_uuid_):
        return self.db_context.query(CoursePdf).filter(CoursePdf.course_uuid == course_uuid_).all()

    def get_all(self):
        return self.db_context.query(CoursePdf).all()

    def count(self):
        return self.db_context.query(CoursePdf).count()

    def delete_all(self):
        return self.db_context.query(CoursePdf).delete()

    def update(self, id_, **kwargs):
        course_pdf = self.db_context.query(CoursePdf).filter(CoursePdf.uuid == id_).first()
        if 'name' in kwargs:
            course_pdf.name = kwargs['name']
        if 'path' in kwargs:
            course_pdf.path = kwargs['path']
        self.db_context.commit()

    def delete_by_uuid(self, id_):
        self.db_context.query(CoursePdf).filter(CoursePdf.uuid == id_).delete()
        self.db_context.commit()
