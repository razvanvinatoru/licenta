import uuid
from Presentation.Server import db
from Bussiness.Repositories.IRepository import IRepository
from Data.Domain.QuestionCourse import QuestionCourse


class QuestionCourseRepository(IRepository):
    def __init__(self):
        super().__init__()

    def add(self, **kwargs):
        question = QuestionCourse(
            uuid=str(uuid.uuid4()),
            user_uuid=kwargs['user_uuid'],
            course_uuid=kwargs['course_uuid'],
            text=kwargs['text'],
            is_edited=kwargs['is_edited'],
            date=kwargs['date'],
            edit_date=kwargs['edit_date']
        )
        self.db_context.add(question)
        self.db_context.commit()
        self.db_context.flush()
        return question.uuid

    def delete_all(self):
        return self.db_context.query(QuestionCourse).delete()

    def delete_by_uuid(self, uuid_):
        self.db_context.query(QuestionCourse).filter(QuestionCourse.uuid == uuid_).delete()
        self.db_context.commit()

    def get_by_course_uuid(self, course_uuid_):
        return self.db_context.query(QuestionCourse).filter(QuestionCourse.course_uuid == course_uuid_).all()

    def get_by_uuid(self, id_):
        return self.db_context.query(QuestionCourse).filter(QuestionCourse.uuid == id_).first()

    def get_all(self):
        pass

    def count(self):
        pass

    def update(self, id_, **kwargs):
        question = self.get_by_uuid(id_)
        if 'text' in kwargs:
            question.text = kwargs['text']
        if 'is_edited' in kwargs:
            question.is_edited = kwargs['is_edited']
        if 'edit_date' in kwargs:
            question.edit_date = kwargs['edit_date']
        self.db_context.commit()
