import uuid
from Bussiness.Repositories.IRepository import IRepository
from Data.Domain.LaboratoryPdf import LaboratoryPdf


class LaboratoryPdfRepository(IRepository):
    def __init__(self):
        super().__init__()

    def add(self, **kwargs):
        laboratory_pdf = LaboratoryPdf(
            uuid=str(uuid.uuid4()),
            laboratory_uuid=kwargs['laboratory_uuid'],
            name=kwargs['name'],
            path=kwargs['path']
        )
        self.db_context.add(laboratory_pdf)
        self.db_context.commit()

    def get_by_uuid(self, uuid_):
        return self.db_context.query(LaboratoryPdf).filter(LaboratoryPdf.uuid == uuid_).first()

    def get_by_laboratory_uuid(self, laboratory_uuid_):
        return self.db_context.query(LaboratoryPdf).filter(LaboratoryPdf.laboratory_uuid == laboratory_uuid_).all()

    def get_all(self):
        return self.db_context.query(LaboratoryPdf).all()

    def count(self):
        return self.db_context.query(LaboratoryPdf).count()

    def delete_all(self):
        return self.db_context.query(LaboratoryPdf).delete()

    def update(self, id_, **kwargs):
        course_pdf = self.db_context.query(LaboratoryPdf).filter(LaboratoryPdf.uuid == id_).first()
        if 'name' in kwargs:
            course_pdf.name = kwargs['name']
        if 'path' in kwargs:
            course_pdf.path = kwargs['path']
        self.db_context.commit()

    def delete_by_uuid(self, id_):
        self.db_context.query(LaboratoryPdf).filter(LaboratoryPdf.uuid == id_).delete()
        self.db_context.commit()
