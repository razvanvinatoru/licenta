from Presentation.Server import db
from Data.Domain.User import User
from Data.Domain.Professor import Professor


class ProfessorRepository:
    db_context = db.session

    def add_professor(self, _uuid, _lastname, _firstname, _email, _password, _didactic_degree,
                      _doctor, _description):
        try:
            user = User(uuid=_uuid, lastname=_lastname, firstname=_firstname,
                        email=_email, password=_password)
            self.db_context.add(user)
            self.db_context.commit()

            db.session.flush()

            professor = Professor(id=user.id, didactic_degree=_didactic_degree, doctor=_doctor,
                                  description=_description)
            db.session.add(professor)
            self.db_context.commit()
        except Exception as exception:
            print("add_professor returned errors: {}".format(exception))

