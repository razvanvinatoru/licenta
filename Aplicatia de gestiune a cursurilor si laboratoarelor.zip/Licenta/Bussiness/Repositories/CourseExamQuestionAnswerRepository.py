import uuid
from Bussiness.Repositories.IRepository import IRepository
from Data.Domain.CourseExamQuestionAnswer import CourseExamQuestionAnswer


class CourseExamQuestionAnswerRepository(IRepository):
    def __init__(self):
        super().__init__()

    def add(self, **kwargs):
        course_exam_question_answer = CourseExamQuestionAnswer(
            uuid=str(uuid.uuid4()),
            course_exam_question_uuid=kwargs['course_exam_question_uuid'],
            answer=kwargs['answer'],
            is_correct=kwargs['is_correct']
        )
        self.db_context.add(course_exam_question_answer)
        self.db_context.commit()

    def get_by_uuid(self, uuid_):
        return self.db_context.query(CourseExamQuestionAnswer).filter(CourseExam.uuid == uuid_).first()

    def get_by_course_exam_question_uuid(self, course_exam_question_uuid_):
        return self.db_context.query(CourseExamQuestionAnswer).filter(
            CourseExamQuestionAnswer.course_exam_question_uuid == course_exam_question_uuid_).all()

    def get_all(self):
        return self.db_context.query(CourseExamQuestionAnswer).all()

    def count(self):
        return self.db_context.query(CourseExamQuestionAnswer).count()

    def delete_all(self):
        return self.db_context.query(CourseExamQuestionAnswer).delete()

    def update(self, id_, **kwargs):
        course_exam_question_answer = self.db_context.query(CourseExamQuestionAnswer).\
            filter(CourseExamQuestionAnswer.uuid == id_).first()
        if 'answer' in kwargs:
            course_exam_question_answer.answer = kwargs['answer']
        if 'is_correct' in kwargs:
            course_exam_question_answer.is_correct = kwargs['is_correct']
        self.db_context.commit()

    def delete_by_uuid(self, id_):
        self.db_context.query(CourseExamQuestionAnswer).filter(CourseExamQuestionAnswer.uuid == id_).delete()
        self.db_context.commit()
