from Presentation.Server import db
from Data.Domain.User import User
from Data.Domain.Student import Student


class StudentRepository:
    db_context = db.session

    def add_student(self, _uuid, _lastname, _firstname, _email, _password):
        try:
            user = User(uuid=_uuid, lastname=_lastname, firstname=_firstname,
                        email=_email, password=_password)
            self.db_context.add(user)
            self.db_context.commit()

            db.session.flush()

            student = Student(id=user.id)
            db.session.add(student)
            self.db_context.commit()
        except Exception as exception:
            print("add_student returned errors: {}".format(exception))

    def update_group(self, _email, _group):
        user = User.query.filter_by(email=_email).first()
        user.student[0].group = _group
        self.db_context.commit()

    def update_year(self, _email, _year):
        user = User.query.filter_by(email=_email).first()
        user.student[0].year = _year
        self.db_context.commit()

    def update_description(self, _email, _description):
        user = User.query.filter_by(email=_email).first()
        user.student[0].description = _description
        self.db_context.commit()
        