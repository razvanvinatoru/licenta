import uuid
from Presentation.Server import db
from Data.Domain.HardcodedProfessor import HardcodedProfessor


class HardcodedProfessorRepository:
    db_context = db.session

    def add_professors(self, _full_name, _email, _didactic_degree, _doctor):
        hardcoded_professor = HardcodedProfessor(
            uuid=str(uuid.uuid4()), full_name=_full_name, email=_email, didactic_degree=_didactic_degree, doctor=_doctor
        )
        db.session.add(hardcoded_professor)
        self.db_context.commit()

    @staticmethod
    def get_professor_by_full_name(_full_name):
        return HardcodedProfessor.query.filter_by(full_name=_full_name).first()

    @staticmethod
    def get_first_professor_by_uuid(_uuid):
        return HardcodedProfessor.query.filter_by(uuid=_uuid).first()

    @staticmethod
    def delete_all_professors():
        HardcodedProfessor.query.delete()
