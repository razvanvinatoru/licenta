import uuid
from Presentation.Server import db
from Bussiness.Repositories.IRepository import IRepository
from Data.Domain.QuestionLaboratory import QuestionLaboratory


class QuestionLaboratoryRepository(IRepository):
    def __init__(self):
        super().__init__()

    def add(self, **kwargs):
        question = QuestionLaboratory(
            uuid=str(uuid.uuid4()),
            user_uuid=kwargs['uuid_user'],
            laboratory_uuid=kwargs['uuid_course'],
            text=kwargs['text'],
            is_edited=kwargs['is_edited'],
            date=kwargs['date'],
            edit_date=kwargs['edit_date']
        )
        self.db_context.add(question)
        self.db_context.commit()

    def delete_all(self):
        return self.db_context.query(QuestionLaboratory).delete()

    def delete_by_uuid(self, uuid_):
        self.db_context.query(QuestionLaboratory).filter(QuestionLaboratory.uuid == uuid_).delete()
        self.db_context.commit()

    def get_by_laboratory_uuid(self, laboratory_uuid):
        return self.db_context.query(QuestionLaboratory).filter(QuestionLaboratory.laboratory_uuid == laboratory_uuid).all()

    def get_by_uuid(self, id_):
        pass

    def get_all(self):
        pass

    def count(self):
        pass

    def update(self, id_, **kwargs):
        pass
