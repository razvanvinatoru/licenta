from Bussiness.Repositories.CourseExamResultRepository import CourseExamResultRepository
from Bussiness.Services.IService import IService


class CourseExamResultService(IService):
    def __init__(self):
        self.__course_exam_result_repository = CourseExamResultRepository()

    def add(self, **kwargs):
        return self.__course_exam_result_repository.add(**kwargs)

    def get_by_uuid(self, uuid_):
        return self.__course_exam_result_repository.get_by_uuid(id_)

    def get_by_course_exam_uuid(self, course_uuid_):
        return self.__course_exam_result_repository.get_by_course_exam_uuid(course_uuid_)

    def get_by_student_uuid(self, student_uuid_):
        return self.__course_exam_result_repository.get_by_student_uuid(student_uuid_)

    def get_by_course_exam_and_student_uuid(self, course_uuid, student_uuid):
        return self.__course_exam_result_repository.get_by_course_exam_and_student_uuid(course_uuid, student_uuid)

    def get_all(self):
        return self.__course_exam_result_repository.get_all()

    def count(self):
        return self.__course_exam_result_repository.count()

    def update(self, id_, **kwargs):
        return self.__course_exam_result_repository.update(id_, **kwargs)

    def delete_all(self):
        return self.__course_exam_result_repository.delete_all()

    def delete_by_uuid(self, uuid_):
        return self.__course_exam_result_repository.delete_by_uuid(uuid_)
