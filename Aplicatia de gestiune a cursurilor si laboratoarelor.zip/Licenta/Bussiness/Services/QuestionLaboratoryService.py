from Bussiness.Repositories.QuestionLaboratoryRepository import QuestionLaboratoryRepository
from Bussiness.Services.IService import IService


class QuestionLaboratoryService(IService):
    def __init__(self):
        self.__question_laboratory_repository = QuestionLaboratoryRepository()

    def add(self, **kwargs):
        return self.__question_laboratory_repository.add(**kwargs)

    def delete_all(self):
        return self.__question_laboratory_repository.delete_all()

    def delete_by_uuid(self, uuid):
        return self.__question_laboratory_repository.delete_by_uuid(uuid)

    def get_by_laboratory_uuid(self, laboratory_uuid):
        return self.__question_laboratory_repository.get_by_laboratory_uuid(laboratory_uuid)

    def update(self, id_, **kwargs):
        pass

    def get_by_uuid(self, uuid_):
        pass

    def get_all(self):
        pass

    def count(self):
        pass
