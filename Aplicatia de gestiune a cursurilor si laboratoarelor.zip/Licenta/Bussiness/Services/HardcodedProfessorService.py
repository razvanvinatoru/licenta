from Bussiness.Repositories.HardcodedProfessorRepository import HardcodedProfessorRepository


class HardcodedProfessorService:

    def __init__(self):
        self.__hardcoded_professor_repository = HardcodedProfessorRepository()

    def add_professors(self, _full_name, _email=None, _didactic_degree=None, _doctor=None):
        return self.__hardcoded_professor_repository.add_professors(
            _full_name=_full_name,
            _email=_email,
            _didactic_degree=_didactic_degree,
            _doctor=_doctor
        )

    def professor_by_full_name(self, _full_name):
        return self.__hardcoded_professor_repository.get_professor_by_full_name(_full_name)

    def get_first_professor_by_uuid(self, _uuid):
        return self.__hardcoded_professor_repository.get_first_professor_by_uuid(_uuid)

    def delete_all_professors(self):
        return self.__hardcoded_professor_repository.delete_all_professors()


