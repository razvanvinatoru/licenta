from Bussiness.Repositories.LaboratoryHomeworkRepository import LaboratoryHomeworkRepository
from Bussiness.Services.IService import IService


class LaboratoryHomeworkService(IService):
    def __init__(self):
        self.__laboratory_homework_repository = LaboratoryHomeworkRepository()

    def add(self, **kwargs):
        return self.__laboratory_homework_repository.add(**kwargs)

    def get_by_uuid(self, uuid_):
        return self.__laboratory_homework_repository.get_by_uuid(id_)

    def get_by_laboratory_uuid_and_name(self, laboratory_uuid_, name_):
        return self.__laboratory_homework_repository.get_by_laboratory_uuid_and_name(laboratory_uuid_, name_)

    def get_by_laboratory_uuid(self, laboratory_uuid_):
        return self.__laboratory_homework_repository.get_by_laboratory_uuid(laboratory_uuid_)

    def get_all(self):
        return self.__laboratory_homework_repository.get_all()

    def count(self):
        return self.__laboratory_homework_repository.count()

    def update(self, id_, **kwargs):
        return self.__laboratory_homework_repository.update(id_, **kwargs)

    def delete_all(self):
        return self.__laboratory_homework_repository.delete_all()

    def delete_by_uuid(self, uuid_):
        return self.__laboratory_homework_repository.delete_by_uuid(uuid_)
