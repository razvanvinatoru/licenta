from Bussiness.Repositories.QuestionCourseRepository import QuestionCourseRepository
from Bussiness.Services.IService import IService


class QuestionCourseService(IService):
    def __init__(self):
        self.__question_course_repository = QuestionCourseRepository()

    def add(self, **kwargs):
        return self.__question_course_repository.add(**kwargs)

    def delete_all(self):
        return self.__question_course_repository.delete_all()

    def delete_by_uuid(self, uuid_):
        return self.__question_course_repository.delete_by_uuid(uuid_)

    def get_by_course_uuid(self, course_uuid_):
        return self.__question_course_repository.get_by_course_uuid(course_uuid_)

    def update(self, id_, **kwargs):
        return self.__question_course_repository.update(id_, **kwargs)

    def get_by_uuid(self, uuid_):
        return self.__question_course_repository.get_by_uuid(uuid_)

    def get_all(self):
        pass

    def count(self):
        pass
