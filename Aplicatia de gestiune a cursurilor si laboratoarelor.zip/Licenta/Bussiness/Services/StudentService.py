from Bussiness.Repositories.StudentRepository import StudentRepository


class StudentService:

    _student_repository = StudentRepository()

    def add_student(self, _uuid, _lastname, _firstname, _email, _password):
        return self._student_repository.add_student(_uuid, _lastname, _firstname, _email, _password)

    def update_group(self, _email, _group):
        return self._student_repository.update_group(_email, _group)

    def update_year(self, _email, _year):
        return self._student_repository.update_year(_email, _year)

    def update_description(self, _email, _description):
        return self._student_repository.update_description(_email, _description)
