from Bussiness.Repositories.PendingAccountRepository import PendingAccountRepository


class PendingAccountService:
    __pending_account_repository = PendingAccountRepository()

    def get_all_pending_accounts(self):
        return self.__pending_account_repository.get_all_pending_accounts()

    def get_first_pending_acc_by_token(self, _token):
        return self.__pending_account_repository.get_first_pending_acc_by_token(_token)

    def add_pending_account(self, _lastname, _firstname, _email, _password, _token,
                            _type_user, _register_date):
        self.__pending_account_repository.add_pending_account(_lastname, _firstname,
                                                              _email, _password, _token,
                                                              _type_user, _register_date)

    def delete_pending_account(self, _id):
        self.__pending_account_repository.delete_pending_account(_id)