from Bussiness.Repositories.ContactMessageRepository import ContactMessageRepository
from Bussiness.Services.IService import IService


class ContactMessageService(IService):
    def __init__(self):
        self.__contact_message_repository = ContactMessageRepository()

    def add(self, **kwargs):
        return self.__contact_message_repository.add(**kwargs)

    def get_by_uuid(self, uuid_):
        return self.__contact_message_repository.get_by_uuid(id_)

    def get_all(self):
        return self.__contact_message_repository.get_all()

    def count(self):
        return self.__contact_message_repository.count()

    def update(self, id_, **kwargs):
        return self.__contact_message_repository.update(id_, **kwargs)

    def delete_all(self):
        return self.__contact_message_repository.delete_all()

    def delete_by_uuid(self, uuid_):
        return self.__contact_message_repository.delete_by_uuid(uuid_)
