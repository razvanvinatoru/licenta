from Bussiness.Repositories.LaboratoryRepository import LaboratoryRepository


class LaboratoryService:
    __laboratory_repository = LaboratoryRepository()

    def add_laboratory(self, _name, _description, _year, _semester, _hardcoded_professors):
        self.__laboratory_repository.add_laboratory(
            _name, _description, _year, _semester, _hardcoded_professors
        )

    def get_all_laboratories(self):
        return self.__laboratory_repository.get_all_laboratories()

    def get_laboratory_by_uuid(self, _uuid):
        return self.__laboratory_repository.get_laboratory_by_uuid(_uuid)

    def get_professor_laboratories_by_laboratory_uuid(self, _uuid):
        return self.__laboratory_repository.get_professor_laboratories_by_laboratory_uuid(_uuid)

    def delete_all_laboratories(self):
        return self.__laboratory_repository.delete_all_laboratories()

    def delete_all_professor_laboratories(self):
        return self.__laboratory_repository.delete_all_professor_laboratories()
