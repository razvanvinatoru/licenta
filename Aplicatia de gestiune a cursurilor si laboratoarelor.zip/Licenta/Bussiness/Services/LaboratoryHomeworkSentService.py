from Bussiness.Repositories.LaboratoryHomeworkSentRepository import LaboratoryHomeworkSentRepository
from Bussiness.Services.IService import IService


class LaboratoryHomeworkSentService(IService):
    def __init__(self):
        self.__laboratory_homework_sent_repository = LaboratoryHomeworkSentRepository()

    def add(self, **kwargs):
        return self.__laboratory_homework_sent_repository.add(**kwargs)

    def get_by_uuid(self, uuid_):
        return self.__laboratory_homework_sent_repository.get_by_uuid(id_)

    def get_by_laboratory_homework_uuid(self, laboratory_homework_uuid):
        return self.__laboratory_homework_sent_repository.get_by_laboratory_uuid(laboratory_homework_uuid)

    def get_by_laboratory_homework_uuid_and_student_uuid(self, laboratory_homework_uuid, student_uuid):
        return self.__laboratory_homework_sent_repository.get_by_laboratory_homework_uuid_and_student_uuid(
            laboratory_homework_uuid,
            student_uuid
        )

    def get_all(self):
        return self.__laboratory_homework_sent_repository.get_all()

    def count(self):
        return self.__laboratory_homework_sent_repository.count()

    def update(self, id_, **kwargs):
        return self.__laboratory_homework_sent_repository.update(id_, **kwargs)

    def delete_all(self):
        return self.__laboratory_homework_sent_repository.delete_all()

    def delete_by_uuid(self, uuid_):
        return self.__laboratory_homework_sent_repository.delete_by_uuid(uuid_)
