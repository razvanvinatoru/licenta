import abc


class IService(abc.ABC):
    @abc.abstractmethod
    def add(self, **kwargs):
        pass

    @abc.abstractmethod
    def get_by_uuid(self, uuid_):
        pass

    @abc.abstractmethod
    def get_all(self):
        pass

    @abc.abstractmethod
    def count(self):
        pass

    @abc.abstractmethod
    def update(self, id_, **kwargs):
        pass

    @abc.abstractmethod
    def delete_all(self):
        pass

    @abc.abstractmethod
    def delete_by_uuid(self, uuid_):
        pass
