from Bussiness.Repositories.CourseRepository import CourseRepository


class CourseService:
    __course_repository = CourseRepository()

    def add(self, _name, _description, _year, _semester, _hardcoded_professors):
        self.__course_repository.add(_name, _description, _year, _semester, _hardcoded_professors)

    def get_all_courses(self):
        return self.__course_repository.get_all_courses()

    def get_course_by_uuid(self, _uuid):
        return self.__course_repository.get_course_by_uuid(_uuid)

    def get_professor_courses_by_course_uuid(self, _course_uuid):
        return self.__course_repository.get_professor_courses_by_course_uuid(_course_uuid)

    def update(self, uuid_, **kwargs):
        return self.__course_repository.update(uuid_, **kwargs)

    def delete_all_course(self):
        self.__course_repository.delete_all_courses()

    def delete_all_professor_courses(self):
        self.__course_repository.delete_all_professor_courses()