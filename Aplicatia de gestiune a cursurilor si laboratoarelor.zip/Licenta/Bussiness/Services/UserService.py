from Bussiness.Repositories.UserRepository import UserRepository


class UserService:
    _user_repository = UserRepository()

    def add(self, **kwargs):
        return self._user_repository.add(**kwargs)

    def get_first_user_by_uuid(self, _uuid):
        return self._user_repository.get_first_user_by_uuid(_uuid)

    def get_first_user_by_email(self, _email):
        return self._user_repository.get_first_user_by_email(_email)

    def verify_if_email_exists(self, _email):
        return self._user_repository.verify_if_email_exists(_email)

    def update_password(self, _email, _password):
        return self._user_repository.update_password(_email, _password)

    def update_lastname(self, _email, _lastname):
        return self._user_repository.update_lastname(_email, _lastname)

    def update_firstname(self, _email, _firstname):
        return self._user_repository.update_firstname(_email, _firstname)

    def update_email(self, _email, _new_email):
        return self._user_repository.update_email(_email, _new_email)
