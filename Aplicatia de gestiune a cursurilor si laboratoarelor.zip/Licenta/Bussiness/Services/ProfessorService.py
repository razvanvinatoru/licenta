from Bussiness.Repositories.ProfessorRepository import ProfessorRepository


class ProfessorService:

    _professor_repository = ProfessorRepository()

    def add_professor(self, _uuid, _lastname, _firstname, _email, _password, _didactic_degree=None,
                      _doctor=None, _description=None):
        return self._professor_repository.add_professor(_uuid, _lastname, _firstname, _email, _password)


