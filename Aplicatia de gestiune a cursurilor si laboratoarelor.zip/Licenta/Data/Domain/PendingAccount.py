from Presentation.Server import db


class PendingAccounts(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(50), unique=True)
    lastname = db.Column(db.String(20), unique=False, nullable=False)
    firstname = db.Column(db.String(20), unique=False, nullable=False)
    email = db.Column(db.String(40), unique=True, nullable=False)
    password = db.Column(db.String(100), unique=False, nullable=False)
    token = db.Column(db.String(100), unique=False, nullable=True)
    type_user = db.Column(db.String(20), unique=False, nullable=False)
    register_date = db.Column(db.DateTime, nullable=False)

    def __repr__(self):
        return f"PendingAccount(" \
               f"{self.id}, " \
               f"{self.uuid}, " \
               f"{self.lastname}, " \
               f"{self.firstname}, " \
               f"{self.email}, " \
               f"{self.password}, " \
               f"{self.token}, " \
               f"{self.type_user}, " \
               f"{self.register_date})"
