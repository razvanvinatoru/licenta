from Presentation.Server import db
from Data.Domain.CourseExam import CourseExam


class CourseExamQuestion(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(50), unique=True)
    course_exam_uuid = db.Column(db.String(50), db.ForeignKey(CourseExam.uuid), nullable=False)
    question = db.Column(db.String(1000), nullable=False)
    score = db.Column(db.Float, nullable=False)

    def __repr__(self):
        return f"\nCourseExamQuestion(" \
               f"{self.uuid}, " \
               f"{self.course_exam_uuid}, " \
               f"{self.question}, " \
               f"{self.score})"
