from Data.Domain.Laboratory import Laboratory
from Presentation.Server import db


class LaboratoryPdf(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(50), unique=True)
    laboratory_uuid = db.Column(db.String(50), db.ForeignKey(Laboratory.uuid), nullable=False)
    name = db.Column(db.String(500), nullable=False)
    path = db.Column(db.String(1000), nullable=False)

    def __repr__(self):
        return f"\nLaboratoryPdf(" \
               f"{self.uuid}, " \
               f"{self.laboratory_uuid}, " \
               f"{self.number}, " \
               f"{self.path})"
