from Presentation.Server import db
from Data.Domain.CourseExam import CourseExam
from Data.Domain.Student import Student


class CourseExamResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(50), unique=True)
    course_exam_uuid = db.Column(db.String(50), db.ForeignKey(CourseExam.uuid), nullable=False)
    student_uuid = db.Column(db.String(50), db.ForeignKey(Student.uuid), nullable=False)
    result = db.Column(db.Float, nullable=False)

    def __repr__(self):
        return f"\nCourseExam(" \
               f"{self.uuid}, " \
               f"{self.course_exam_uuid}, " \
               f"{self.student_uuid}, " \
               f"{self.result})"
