from Presentation.Server import db
from Data.Domain.User import User


class Student(db.Model):
    id = db.Column(db.Integer, db.ForeignKey(User.id, ondelete='CASCADE'), primary_key=True)
    uuid = db.Column(db.String(50), unique=True)
    year = db.Column(db.String(10), unique=False, nullable=True)
    group = db.Column(db.String(10), unique=False, nullable=True)
    description = db.Column(db.String(200), unique=False, nullable=True)

    def __repr__(self):
        return f"ProfessorLab(" \
               f"{self.id}, " \
               f"{self.uuid}, " \
               f"{self.year}, " \
               f"{self.group}, " \
               f"{self.description})"
