from Presentation.Server import db


class Laboratory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(50), unique=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(1000), nullable=False)
    year = db.Column(db.Integer, unique=False, nullable=False)
    semester = db.Column(db.Integer, unique=False, nullable=False)

    def __repr__(self):
        return " Laboratory(\n\tuuid: " + str(self.uuid) + "\n\tname: " + self.name + "\n\tdescription: " + \
               self.description + "\n\tyear: " + str(self.year) + "\n\tsemester: " + str(self.semester) + "\n"