from Presentation.Server import db


class HardcodedProfessor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(50), unique=True)
    full_name = db.Column(db.String(200), unique=False, nullable=False)
    email = db.Column(db.String(40), unique=True, nullable=True)
    didactic_degree = db.Column(db.String(30), unique=False, nullable=False)
    doctor = db.Column(db.Boolean, unique=False, nullable=True, default=False)

    def __repr__(self):
        return "HardcodedProfessor(\n" \
               "\tfull_name: " + str(self.full_name) + "\n" \
               "\tdidactic_degree: " + str(self.didactic_degree) + "\n" \
               "\tDescription: " + str(self.doctor) + "\n" \
               + ")\n"
