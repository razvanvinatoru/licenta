from Presentation.Server import db
from Data.Domain.Course import Course
from Data.Domain.User import User


class QuestionCourse(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(50), unique=True)
    user_uuid = db.Column(db.String(50), db.ForeignKey(User.uuid), nullable=False)
    course_uuid = db.Column(db.String(50), db.ForeignKey(Course.uuid), nullable=False)
    text = db.Column(db.String(500), unique=False, nullable=False)
    is_edited = db.Column(db.Boolean, unique=False, nullable=True, default=False)
    date = db.Column(db.DateTime, nullable=False)
    edit_date = db.Column(db.DateTime, nullable=True)

    def __repr__(self):
        return f"QuestionCourse(" \
               f"{self.id}, " \
               f"{self.uuid}, " \
               f"{self.user_uuid}, " \
               f"{self.course_uuid}, " \
               f"{self.text}, " \
               f"{self.is_edited}, " \
               f"{self.date}, " \
               f"{self.edit_date})"
