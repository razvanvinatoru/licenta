from Presentation.Server import db
from Data.Domain.User import User


class Professor(db.Model):
    id = db.Column(db.Integer, db.ForeignKey(User.id, ondelete='CASCADE'), primary_key=True)
    uuid = db.Column(db.String(50), unique=True)
    description = db.Column(db.String(200), unique=False, nullable=True)
    didactic_degree = db.Column(db.String(30), unique=False, nullable=True)
    doctor = db.Column(db.Boolean, unique=False, nullable=True, default=False)

    def __repr__(self):
        return f"Professor(" \
               f"{self.id}, " \
               f"{self.uuid}, " \
               f"{self.description}, " \
               f"{self.didactic_degree}, " \
               f"{self.doctor})"
