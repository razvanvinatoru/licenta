from Presentation.Server import db


class ContactMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(50), unique=True)
    email_reviewer = db.Column(db.String(40), unique=False, nullable=False)
    text = db.Column(db.String(300), unique=False, nullable=False)
    message_date = db.Column(db.DateTime, nullable=False)

    def __repr__(self):
        return f"\nContactMessage(" \
               f"{self.uuid}, " \
               f"{self.email_reviewer}, " \
               f"{self.text}, " \
               f"{self.message_date})"
