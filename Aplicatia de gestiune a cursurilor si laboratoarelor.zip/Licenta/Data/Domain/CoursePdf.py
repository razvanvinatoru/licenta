from Presentation.Server import db
from Data.Domain.Course import Course


class CoursePdf(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(50), unique=True)
    course_uuid = db.Column(db.String(50), db.ForeignKey(Course.uuid), nullable=False)
    name = db.Column(db.String(500), nullable=False)
    path = db.Column(db.String(100), nullable=True)

    def __repr__(self):
        return f"\nCoursePdf(" \
               f"{self.uuid}, " \
               f"{self.course_uuid}, " \
               f"{self.name}, " \
               f"{self.path})"
