from Presentation.Server import db
from Data.Domain.Course import Course
from Data.Domain.HardcodedProfessor import HardcodedProfessor


class ProfessorCourse(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    id_course = db.Column(db.String(50), db.ForeignKey(Course.uuid), nullable=False)
    id_professor = db.Column(db.String(50), db.ForeignKey(HardcodedProfessor.uuid), nullable=False)

    def __repr__(self):
        return f"ProfessorCourse(" \
               f"{self.id}, " \
               f"{self.id_course}, " \
               f"{self.id_professor})"
