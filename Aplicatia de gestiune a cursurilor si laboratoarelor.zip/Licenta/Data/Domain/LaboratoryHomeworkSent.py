from Data.Domain.LaboratoryHomework import LaboratoryHomework
from Data.Domain.Student import  Student
from Presentation.Server import db


class LaboratoryHomeworkSent(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(50), unique=True)
    student_uuid = db.Column(db.String(50), db.ForeignKey(Student.uuid), nullable=False)
    laboratory_homework_uuid = db.Column(db.String(50), db.ForeignKey(LaboratoryHomework.uuid), nullable=False)
    path = db.Column(db.String(1000), nullable=False)
    date = db.Column(db.DateTime, nullable=False)

    def __repr__(self):
        return f"\nLaboratoryHomeworkSent(" \
               f"{self.uuid}, " \
               f"{self.student_uuid}, " \
               f"{self.laboratory_homework_uuid}, " \
               f"{self.path}, " \
               f"{self.date}"
