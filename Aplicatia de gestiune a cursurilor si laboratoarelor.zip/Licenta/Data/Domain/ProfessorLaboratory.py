from Presentation.Server import db
from Data.Domain.Laboratory import Laboratory
from Data.Domain.HardcodedProfessor import HardcodedProfessor


class ProfessorLab(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    id_laboratory = db.Column(db.String(50), db.ForeignKey(Laboratory.uuid), nullable=False)
    id_professor = db.Column(db.String(50), db.ForeignKey(HardcodedProfessor.uuid), nullable=False)

    def __repr__(self):
        return f"ProfessorLab(" \
               f"{self.id}, " \
               f"{self.id_laboratory}, " \
               f"{self.id_professor})"
