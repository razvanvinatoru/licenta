from Presentation.Server import db
from Data.Domain.CoursePdf import CoursePdf


class CourseExam(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(50), unique=True)
    course_pdf_uuid = db.Column(db.String(50), db.ForeignKey(CoursePdf.uuid), nullable=False)
    duration_minutes = db.Column(db.Integer, nullable=False)
    start_date = db.Column(db.DateTime, nullable=False)
    details = db.Column(db.String(1000), nullable=True)

    @property
    def as_dict(self):
        return {
            "uuid": self.uuid,
            "course_pdf_uuid": self.course_pdf_uuid,
            "duration_minutes": self.duration_minutes,
            "start_date": self.start_date,
            "details": self.details
        }

    def __repr__(self):
        return f"\nCourseExam(" \
               f"{self.uuid}, " \
               f"{self.course_pdf_uuid}, " \
               f"{self.duration_minutes}, " \
               f"{self.start_date}, " \
               f"{self.details})"
