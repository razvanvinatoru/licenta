from Presentation.Server import db
from Data.Domain.CourseExamQuestion import CourseExamQuestion


class CourseExamQuestionAnswer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(50), unique=True)
    course_exam_question_uuid = db.Column(db.String(50), db.ForeignKey(CourseExamQuestion.uuid), nullable=False)
    answer = db.Column(db.String(500), nullable=False)
    is_correct = db.Column(db.Boolean, nullable=False)

    def __repr__(self):
        return f"\nCourseExamQuestionAnswer(" \
               f"{self.uuid}, " \
               f"{self.course_exam_question_uuid}, " \
               f"{self.answer}, " \
               f"{self.is_correct})" \
