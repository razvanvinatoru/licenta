from Presentation.Server import db


class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(50), unique=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(1000), nullable=False)
    year = db.Column(db.Integer, unique=False, nullable=False)
    semester = db.Column(db.Integer, unique=False, nullable=False)

    def data(self):
        return {
            "id": {self.id},
            "uuid": {self.uuid},
            "name": {self.name},
            "description": {self.description},
            "year": {self.year},
            "semester": {self.semester}
        }

    def __repr__(self):
        return f"\nCourse('" \
               f"{self.uuid}', " \
               f"'{self.id_professor}', " \
               f"'{self.name}', " \
               f"'{self.description}', " \
               f"'{self.year}', " \
               f"'{self.semester}')"
