from Presentation.Server import db
from Data.Domain.User import User
from Data.Domain.Laboratory import Laboratory


class QuestionLaboratory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(50), unique=True)
    user_uuid = db.Column(db.String(50), db.ForeignKey(User.uuid), nullable=False)
    laboratory_uuid = db.Column(db.String(50), db.ForeignKey(Laboratory.uuid), nullable=False)
    text = db.Column(db.String(500), unique=False, nullable=False)
    is_edit = db.Column(db.Boolean, unique=False, nullable=True, default=False)
    date = db.Column(db.DateTime, nullable=False)
    edit_date = db.Column(db.DateTime, nullable=True)

    def __repr__(self):
        return f"QuestionLaboratory(" \
               f"{self.id}, " \
               f"{self.uuid}, " \
               f"{self.user_uuid}, " \
               f"{self.laboratory_uuid}, " \
               f"{self.text}, " \
               f"{self.is_edit}, " \
               f"{self.date}, " \
               f"{self.edit_date})"
