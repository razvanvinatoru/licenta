import re
from flask import url_for
from random import choice, randint
from itsdangerous import URLSafeTimedSerializer, SignatureExpired
from string import ascii_uppercase, ascii_lowercase, digits
from Presentation.Server import Message, mail

from Bussiness.Services.UserService import UserService
from Bussiness.Services.PendingAccountService import PendingAccountService

_user_service = UserService()
_pending_acc_service = PendingAccountService()

serializer = URLSafeTimedSerializer('itissecret!')


def verify_register_form(data):
    if data["lastname"] == "" or data["firstname"] == "" \
            or data["email"] == "" or data["password"] == "" \
            or data["confirm_password"] == "":
        return {
            "passed": False,
            "message": "Campurile nu au voie sa fie goale!"
        }

    elif len(data["lastname"]) < 3 or len(data["lastname"]) > 20:
        return {
            "passed": False,
            "message": "Numele trebuie sa fie intre 3 si 20 de litere!"
        }

    elif len(data["lastname"].split()) > 1:
        return {
            "passed": False,
            "message": "Numele nu poate fi compus din mai multe cuvinte"
        }

    elif not re.match("^[a-zA-Z]+$", data["lastname"]):
        return {
            "passed": False,
            "message": "Numele trebuie sa contina doar litere!"
        }

    elif len(data["firstname"]) < 3 or len(data["firstname"]) > 20:
        return {
            "passed": False,
            "message": "Prenumele trebuie sa fie intre 3 si 20 de litere!"
        }

    elif not re.match("^[a-zA-Z]+$", data["firstname"]):
        return {
            "passed": False,
            "message": "Prenumele trebuie sa contina doar litere!"
        }

    elif not re.match("^[\w|.]+@[\w|.]+$", data["email"]):
        return {
            "passed": False,
            "message": "Email-ul trebuie sa fie de forma email@info.uaic.ro!"
        }

    elif _user_service.verify_if_email_exists(data["email"]):
        return {
            "passed": False,
            "message": "Exista deja un utilizator ce-a folosit acest email!"
        }

    elif len(data["password"]) < 6 or len(data["password"]) > 30:
        return {
            "passed": False,
            "message": "Parola trebuie sa fie intre 6 si 30 de caractere!"
        }

    elif len(data["confirm_password"]) < 6 or len(data["confirm_password"]) > 30:
        return {
            "passed": False,
            "message": "Confirmarea parolei trebuie sa fie intre 6 si 30 de caractere!"
        }

    elif not re.match("^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$", data["password"]):
        return {
            "passed": False,
            "message": "Parola trebuie sa fie formata din litere mici, mari si cifre!"
        }

    elif not re.match("^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$",
                      data["confirm_password"]):
        return {
            "passed": False,
            "message": "Confirmarea parolei trebuie sa fie formata din litere mici, mari si cifre!"
        }

    elif data["password"] != data["confirm_password"]:
        return {
            "passed": False,
            "message": "Parolele introduse trebuie sa fie identice!"
        }

    else:
        return {
            "passed": True,
            "message": "Un email de confirmare a fost trimis la " + data["email"].lower() +
                       "!"
        }


def verify_login_form(data):
    if data["email"] == "" or data["password"] == "":
        return {
            "passed": False,
            "message": "Campurile nu au voie sa fie goale!"
        }
    else:
        return {
            "passed": True,
            "message": "Ai reusit sa te loghezi cu succes!"
        }


def verify_forgot_password_form(data):
    user = _user_service.get_first_user_by_email(data["email"])

    if data["email"] == "":
        return {
            "passed": False,
            "message": "Campurile nu au voie sa fie goale!"
        }
    elif not user:
        return {
            "passed": False,
            "message": "Acest email nu este folosit de niciun utilizator!"
        }
    else:
        return {
            "passed": True,
            "message": "Un email cu noua parola a fost trimis catre " + data["email"] + "!"
        }


def send_confirmation_email(email, lastname, firstname):
    token = serializer.dumps(email, salt='email-confirm')
    msg = Message('[Confirmare email] Aplicatie FII', sender='fii.courses.laboratories@gmail.com',
                  recipients=[email])

    link = url_for('confirm_email', token=token, _external=True)

    print(link)

    msg.body = 'Multumim pentru inregistrare {} {} acest email a fost trimis cu scopul de a vedea daca adresa inregistrarii este una reala \n' \
               'Linkul tau de confirmare este: {}'.format(lastname, firstname, link)
    mail.send(msg)

    return token


def send_password_email(email, password):
    token = serializer.dumps(email, salt='password')
    msg = Message('[Recuperare parola] Aplicatie FII', sender='apetreialinc@gmail.com',
                  recipients=['synceed96@gmail.com'])

    msg.body = 'Acest email a fost trimis la cererea dumneavoastra cu privire la uitarea parolei \n' \
               'Parola noua poate fi schimbata in aplicatie la sectiunea detalii \n' \
               'Noua parola este: {}'.format(password)

    # mail.send(msg)

    return token


def verify_token(token):
    pending_account = _pending_acc_service.get_first_pending_acc_by_token(token)
    if pending_account:
        return True
    return False


def get_random_password():
    return ''.join(choice(ascii_uppercase + ascii_lowercase + digits) for _ in range(randint(6, 30)))