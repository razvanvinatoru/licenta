import os
import re
import shutil
from datetime import datetime
from flask import url_for
from random import choice, randint
from itsdangerous import URLSafeTimedSerializer, SignatureExpired
from string import ascii_uppercase, ascii_lowercase, digits
from Presentation.Server import Message, mail

from Bussiness.Services.UserService import UserService
from Bussiness.Services.CourseService import CourseService
from Bussiness.Services.LaboratoryService import LaboratoryService
from Bussiness.Services.HardcodedProfessorService import HardcodedProfessorService
from Bussiness.Services.QuestionCourseService import QuestionCourseService
from Bussiness.Services.QuestionLaboratoryService import QuestionLaboratoryRepository
from Bussiness.Services.CoursePdfService import CoursePdfService
from Bussiness.Services.LaboratoryPdfService import LaboratoryPdfService
from Bussiness.Services.LaboratoryHomeworkService import LaboratoryHomeworkService
from Bussiness.Services.CourseExamService import CourseExamService
from Bussiness.Services.CourseExamQuestionService import CourseExamQuestionService
from Bussiness.Services.CourseExamQuestionAnswerService import CourseExamQuestionAnswerService

_user_service = UserService()
_course_service = CourseService()
_laboratory_service = LaboratoryService()
_laboratory_pdf_service = LaboratoryPdfService()
_laboratory_homework_service = LaboratoryHomeworkService()
_hardcoded_professor_service = HardcodedProfessorService()
_question_course_service = QuestionCourseService()
_question_laboratory_service = QuestionLaboratoryRepository()
_course_pdf_service = CoursePdfService()
_course_exam_service = CourseExamService()
_course_exam_question_service = CourseExamQuestionService()
_course_exam_question_answer_service = CourseExamQuestionAnswerService()

hardcoded_professors = {
    "florin_iacob": {
        "nume": "Florin Iacob",
        "doctor": True,
        "email": "fliacob@info.uaic.ro",
        "grad_didactic": "Lector"
    },
    "andreea_arusoaie": {
        "nume": "Andreea Arusoaie",
        "doctor": True,
        "grad_didactic": "Asistent"
    },
    "adrian_zalinescu": {
        "nume": "Adrian Zalinescu",
        "doctor": True,
        "grad_didactic": "Conferentiar"
    },
    "bogdan_patrut": {
        "nume": "Bogdan Patrut",
        "doctor": True,
        "grad_didactic": "Lector"
    },
    "madalina_raschip": {
        "nume": "Madalina Raschip",
        "doctor": True,
        "grad_didactic": "Conferentiar"
    },
    "cristian_gatu": {
        "nume": "Cristian Gatu",
        "doctor": True,
        "grad_didactic": "Conferentiar"
    },
    "stefan_ciobaca": {
        "nume": "Stefan Ciobaca",
        "doctor": True,
        "grad_didactic": "Conferentiar"
    },
    "andrei_arusoaie": {
        "nume": "Andrei Arusoaie",
        "doctor": True,
        "grad_didactic": "Lector"
    },
    "vlad_radulescu": {
        "nume": "Vlad Radulescu",
        "doctor": True,
        "grad_didactic": "Lector"
    },
    "dorel_lucanu": {
        "nume": "Dorel Lucanu",
        "doctor": True,
        "grad_didactic": "Profesor"
    },
    "dragos_gavrilut": {
        "nume": "Dragos Gavrilut",
        "doctor": True,
        "grad_didactic": "Conferentiar"
    },
    "tiplea_ferucio_laurentiu": {
        "nume": "Tiplea Ferucio Laurentiu",
        "doctor": True,
        "grad_didactic": "Profesor"
    },
    "olariu_emanuel_florentin": {
        "nume": "Olariu Emanuel Florentin",
        "doctor": True,
        "grad_didactic": "Lector"
    },
    "cristian_vidrascu": {
        "nume": "Cristian Vidrascu",
        "doctor": True,
        "grad_didactic": "Lector"
    },
    "lenuta_alboaie": {
        "nume": "Lenuta Alboaie",
        "doctor": True,
        "grad_didactic": "Conferentiar"
    },
    "mihaela_breaban": {
        "nume": "Mihaela Breaban",
        "doctor": True,
        "grad_didactic": "Conferentiar"
    },
    "cosmin_varlan": {
        "nume": "Cosmin Varlan",
        "doctor": True,
        "grad_didactic": "Lector"
    },
    "oana_captarencu": {
        "nume": "Captarencu Oana",
        "doctor": True,
        "grad_didactic": "Lector"
    },
    "moruz_alex": {
        "nume": "Moruz Alex",
        "doctor": True,
        "grad_didactic": "Lector"
    },
    "cristian_frasinaru": {
        "nume": "Frasinaru Cristian",
        "doctor": True,
        "grad_didactic": "Lector"
    },
    "henri_luchian": {
        "nume": "Henri Luchian",
        "doctor": True,
        "grad_didactic": "Profesor"
    },
    "corneliu_sabin_buraga": {
        "nume": "Corneliu Sabin Buraga",
        "doctor": True,
        "grad_didactic": "Conferentiar"
    },
    "adrian_iftene": {
        "nume": "Adrian Iftene",
        "doctor": True,
        "email": "adiftene@info.uaic.ro",
        "grad_didactic": "Conferentiar"
    },
    "corina_forascu": {
        "nume": "Corina Forascu",
        "doctor": True,
        "grad_didactic": "Conferentiar"
    },
    "liviu_ciortuz": {
        "nume": "Liviu Ciortuz",
        "doctor": True,
        "grad_didactic": "Conferentiar"
    },
    "cristea_dan": {
        "nume": "Cristea Dan",
        "doctor": True,
        "grad_didactic": "Profesor"
    },
    "florin_olariu": {
        "nume": "Florin Olariu",
        "doctor": False,
        "grad_didactic": "Colaborator"
    },
    "mihai_benchea": {
        "nume": "Mihai-Razvan Benchea",
        "doctor": True,
        "grad_didactic": "Lector"
    },
    "anca_vitcu": {
        "nume": "Anca Vitcu",
        "doctor": True,
        "grad_didactic": "Conferentiar"
    },
    "lupu_alexandru": {
        "nume": "Alexandru Lupu",
        "doctor": False,
        "grad_didactic": "Colaborator"
    },
    "anca_ignat": {
        "nume": "Anca Ignat",
        "doctor": True,
        "grad_didactic": "Lector"
    },
    "constantin_lucian_ghirvu": {
        "nume": "Constantin-Lucian Ghirvu",
        "doctor": True,
        "grad_didactic": "Lector"
    },
    "sorin_iftene": {
        "nume": "Sorin Iftene",
        "doctor": True,
        "grad_didactic": "Lector"
    },
    "armanu_nicoleta": {
        "nume": "Nicoleta Armanu",
        "doctor": True,
        "grad_didactic": "Asistent"
    },
    "catalin_birjoveanu": {
        "nume": "Catalin Birjoveanu",
        "doctor": True,
        "grad_didactic": "Lector"
    },
    "ioan_asiminei": {
        "nume": "Ioan Asiminei",
        "doctor": True,
        "grad_didactic": "Lector"
    },
    "rodica_condurache": {
        "nume": "Rodica Condurache",
        "doctor": True,
        "grad_didactic": "Lector"
    },
    "paula_andreea_onofrei": {
        "nume": "Paula-Andreea Onofrei",
        "doctor": True,
        "grad_didactic": "Lector"
    },
    "andrei_panu": {
        "nume": "Andrei Panu",
        "doctor": True,
        "grad_didactic": "Asistent"
    },
    "ionut_pistol": {
        "nume": "Ionut Pistol",
        "doctor": True,
        "grad_didactic": "Lector"
    },
    "nicolae_eugen_croitoru": {
        "nume": "Nicolae-Eugen Croitoru",
        "doctor": True,
        "grad_didactic": "Asistent"
    },
    "diana_trandabat": {
        "nume": "Diana Trandabat",
        "doctor": True,
        "grad_didactic": "Conferentiar"
    }
}


def clear_db():
    _course_pdf_service.delete_all()
    # _question_course_service.delete_all()
    # _question_laboratory_service.delete_all()
    # _course_service.delete_all_professor_courses()
    # _laboratory_service.delete_all_professor_laboratories()
    # _course_service.delete_all_course()
    # _laboratory_service.delete_all_laboratories()
    # _hardcoded_professor_service.delete_all_professors()


def generate_students():
    _user_service.add(**{
        'lastname': 'Vinatoru',
        'firstname': 'Razvan',
        'email': 'razvan.vinatoru@info.uaic.ro',
        'password': bcrypt.generate_password_hash('rvinatoru').decode('UTF-8')
    })


def generate_professors():
    for professor in hardcoded_professors:
        if "email" in hardcoded_professors[professor]:
            _hardcoded_professor_service.add_professors(_full_name=hardcoded_professors[professor]["nume"],
                                                        _email=hardcoded_professors[professor]["email"],
                                                        _didactic_degree=hardcoded_professors[professor]["grad_didactic"],
                                                        _doctor=hardcoded_professors[professor]["doctor"])
        else:
            _hardcoded_professor_service.add_professors(_full_name=hardcoded_professors[professor]["nume"],
                                                        _didactic_degree=hardcoded_professors[professor]["grad_didactic"],
                                                        _doctor=hardcoded_professors[professor]["doctor"])


def generate_courses():
    courses_per_semesters = {
        "an1_sem1" : {
            "Matematică" : [
                hardcoded_professors["florin_iacob"],
                hardcoded_professors["andreea_arusoaie"],
                hardcoded_professors["adrian_zalinescu"]
            ],
            "Introducere în programare": [
                hardcoded_professors["bogdan_patrut"]
            ],
            "Structuri de date": [
                hardcoded_professors["madalina_raschip"],
                hardcoded_professors["cristian_gatu"]
            ],
            "Logică pentru informatică": [
                hardcoded_professors["stefan_ciobaca"],
                hardcoded_professors["andrei_arusoaie"]
            ],
            "ACSO": [
                hardcoded_professors["vlad_radulescu"]
            ]
        },
        "an1_sem2" : {
            "Programare orientată obiect": [
                hardcoded_professors["dorel_lucanu"],
                hardcoded_professors["dragos_gavrilut"]
            ],
            "FAI": [
                hardcoded_professors["tiplea_ferucio_laurentiu"]
            ],
            "Probabilistică și statistică": [
                hardcoded_professors["olariu_emanuel_florentin"],
                hardcoded_professors["adrian_zalinescu"]
            ],
            "Proiectarea algoritmilor": [
                hardcoded_professors["dorel_lucanu"],
                hardcoded_professors["stefan_ciobaca"]
            ],
            "Sisteme de operare": [
                hardcoded_professors["cristian_vidrascu"]
            ]
        },
        "an2_sem1" : {
            "Rețele de calculatoare": [
                hardcoded_professors["lenuta_alboaie"]
            ],
            "Baze de date": [
                hardcoded_professors["mihaela_breaban"],
                hardcoded_professors["cosmin_varlan"]
            ],
            "LFAC": [
                hardcoded_professors["oana_captarencu"],
                hardcoded_professors["moruz_alex"]
            ],
            "Algoritmica grafurilor": [
                hardcoded_professors["olariu_emanuel_florentin"],
                hardcoded_professors["cristian_frasinaru"]
            ],
            "PLP": [
                hardcoded_professors["andrei_arusoaie"]
            ],
            "Algoritmi genetici": [
                hardcoded_professors["henri_luchian"]
            ],
            "CDC": [
                hardcoded_professors["tiplea_ferucio_laurentiu"]
            ]
        },
        "an2_sem2" : {
            "Tehnologii WEB": [
                hardcoded_professors["corneliu_sabin_buraga"]
            ],
            "Programare avansată": [
                hardcoded_professors["cristian_frasinaru"]
            ],
            "Ingineria Programării": [
                hardcoded_professors["adrian_iftene"],
                hardcoded_professors["moruz_alex"]
            ],
            "Practica SGBD": [
                hardcoded_professors["cosmin_varlan"]
            ],
            "Programare funcţională": [
                hardcoded_professors["stefan_ciobaca"]
            ],
            "Modele continue şi Matlab": [
                hardcoded_professors["florin_iacob"]
            ],
            "Introducere in criptografie": [
                hardcoded_professors["tiplea_ferucio_laurentiu"]
            ],
            "Antreprenoriat și inovare în IT": [
                hardcoded_professors["corina_forascu"]
            ]
        },
        "an3_sem1" : {
            "Învățare automată": [
                hardcoded_professors["liviu_ciortuz"]
            ],
            "Securitatea informaţiei": [
                hardcoded_professors["tiplea_ferucio_laurentiu"]
            ],
            "Inteligenţă artificială": [
                hardcoded_professors["cristea_dan"]
            ],
            "Programare în Python": [
                hardcoded_professors["dragos_gavrilut"]
            ],
            "Introducere în .NET": [
                hardcoded_professors["florin_olariu"],
                hardcoded_professors["andrei_arusoaie"]
            ],
            "DSFUM": [
                hardcoded_professors["cosmin_varlan"]
            ],
            "Rețele neuronale": [
                hardcoded_professors["mihai_benchea"]
            ],
            "Animaţie 3D": [
                hardcoded_professors["anca_vitcu"]
            ],
            "PMP": [
                hardcoded_professors["dorel_lucanu"]
            ],
            "Dezvoltarea aplicațiilor Web": [
                hardcoded_professors["corneliu_sabin_buraga"]
            ],
            "CSSO": [
                hardcoded_professors["cristian_vidrascu"]
            ],
            "ISSA": [
                hardcoded_professors["lupu_alexandru"]
            ]
        },
        "an3_sem2" : {
            "Calcul numeric": [
                hardcoded_professors["anca_ignat"]
            ],
            "Grafică pe calculator": [
                hardcoded_professors["constantin_lucian_ghirvu"]
            ],
            "Programare bazată pe reguli": [
                hardcoded_professors["cristea_dan"]
            ],
            "TPPA": [
                hardcoded_professors["dragos_gavrilut"]
            ],
            "ARMS": [
                hardcoded_professors["anca_vitcu"]
            ],
            "ACTN": [
                hardcoded_professors["sorin_iftene"]
            ],
            "PCPIT": [
                hardcoded_professors["armanu_nicoleta"]
            ],
            "Programare MS-Office": [
                hardcoded_professors["vlad_radulescu"]
            ],
            "Cloud Computing": [
                hardcoded_professors["lenuta_alboaie"]
            ],
            "MLMOS": [
                hardcoded_professors["corneliu_sabin_buraga"]
            ],
            "Rețele Petrii și aplicații": [
                hardcoded_professors["oana_captarencu"]
            ],
            "Smart Card-uri și Aplicații": [
                hardcoded_professors["catalin_birjoveanu"]
            ],
            "TSP": [
                hardcoded_professors["ioan_asiminei"]
            ],
            "TILU": [
                hardcoded_professors["cristea_dan"]
            ]
        }
    }

    for courses_semester in courses_per_semesters:
        for course in courses_per_semesters[courses_semester]:
            print(course)
            _course_service.add(
                _name=course,
                _description="Descriere pentru materia {}".format(course),
                _year=int(courses_semester[2]),
                _semester=int(courses_semester[7]),
                _hardcoded_professors=courses_per_semesters[courses_semester][course]
            )


def generate_laboratories():
    laboratories_per_semesters = {
        "an1_sem1" : {
            "Matematică": [
                hardcoded_professors["florin_iacob"],
                hardcoded_professors["corina_forascu"],
                hardcoded_professors["adrian_zalinescu"]
            ],
            "Introducere în programare": [
                hardcoded_professors["bogdan_patrut"]
            ],
            "Structuri de date": [
                hardcoded_professors["madalina_raschip"],
                hardcoded_professors["cristian_gatu"]
            ],
            "Logică pentru informatică": [
                hardcoded_professors["stefan_ciobaca"],
                hardcoded_professors["andrei_arusoaie"],
                hardcoded_professors["rodica_condurache"]
            ],
            "ACSO": [
                hardcoded_professors["vlad_radulescu"]
            ],
            "Limba engleza I": [
                hardcoded_professors["paula_andreea_onofrei"]
            ]
        },
        "an1_sem2" : {
            "Programare orientată obiect": [
                hardcoded_professors["dragos_gavrilut"]
            ],
            "FAI": [
                hardcoded_professors["tiplea_ferucio_laurentiu"]
            ],
            "Probabilistică și statistică": [
                hardcoded_professors["olariu_emanuel_florentin"],
                hardcoded_professors["adrian_zalinescu"]
            ],
            "Proiectarea algoritmilor": [
                hardcoded_professors["andrei_arusoaie"]
            ],
            "Sisteme de operare": [
                hardcoded_professors["cristian_vidrascu"]
            ],
            "Limba engleza II": [
                hardcoded_professors["paula_andreea_onofrei"]
            ]
        },
        "an2_sem1" : {
            "Rețele de calculatoare": [
                hardcoded_professors["lenuta_alboaie"]
            ],
            "Baze de date": [
                hardcoded_professors["mihaela_breaban"],
                hardcoded_professors["cosmin_varlan"]
            ],
            "LFAC": [
                hardcoded_professors["oana_captarencu"],
                hardcoded_professors["moruz_alex"]
            ],
            "Algoritmica grafurilor": [
                hardcoded_professors["olariu_emanuel_florentin"],
                hardcoded_professors["cristian_frasinaru"]
            ],
            "PLP": [
                hardcoded_professors["andrei_arusoaie"]
            ],
            "Algoritmi genetici": [
                hardcoded_professors["mihaela_breaban"]
            ],
            "CDC": [
                hardcoded_professors["tiplea_ferucio_laurentiu"]
            ],
            "Limba engleza III": [
                hardcoded_professors["armanu_nicoleta"]
            ]
        },
        "an2_sem2" : {
            "Tehnologii WEB": [
                hardcoded_professors["andrei_panu"]
            ],
            "Programare avansată": [
                hardcoded_professors["cristian_frasinaru"]
            ],
            "Ingineria Programării": [
                hardcoded_professors["adrian_iftene"],
                hardcoded_professors["moruz_alex"],
                hardcoded_professors["ionut_pistol"],
                hardcoded_professors["andrei_arusoaie"],
                hardcoded_professors["florin_olariu"]
            ],
            "Practica SGBD": [
                hardcoded_professors["cosmin_varlan"]
            ],
            "Programare funcţională": [
                hardcoded_professors["andrei_arusoaie"]
            ],
            "Modele continue şi Matlab": [
                hardcoded_professors["florin_iacob"]
            ],
            "Introducere in criptografie": [
                hardcoded_professors["tiplea_ferucio_laurentiu"]
            ],
            "Antreprenoriat și inovare în IT": [
                hardcoded_professors["corina_forascu"]
            ],
            "Limba engleza IV": [
                hardcoded_professors["armanu_nicoleta"]
            ]
        },
        "an3_sem1" : {
            "Învățare automată": [
                hardcoded_professors["liviu_ciortuz"],
                hardcoded_professors["mihaela_breaban"],
                hardcoded_professors["anca_ignat"]
            ],
            "Securitatea informaţiei": [
                hardcoded_professors["madalina_raschip"],
                hardcoded_professors["ionut_pistol"]
            ],
            "Inteligenţă artificială": [
                hardcoded_professors["cristea_dan"]
            ],
            "Programare în Python": [
                hardcoded_professors["dragos_gavrilut"]
            ],
            "Introducere în .NET": [
                hardcoded_professors["florin_olariu"]
            ],
            "DSFUM": [
                hardcoded_professors["cosmin_varlan"]
            ],
            "Rețele neuronale": [
                hardcoded_professors["mihai_benchea"]
            ],
            "Animaţie 3D": [
                hardcoded_professors["anca_vitcu"]
            ],
            "PMP": [
                hardcoded_professors["dorel_lucanu"]
            ],
            "Dezvoltarea aplicațiilor Web": [
                hardcoded_professors["corneliu_sabin_buraga"]
            ],
            "CSSO": [
                hardcoded_professors["cristian_vidrascu"]
            ],
            "ISSA": [
                hardcoded_professors["lupu_alexandru"]
            ]
        },
        "an3_sem2" : {
            "Calcul numeric": [
                hardcoded_professors["andreea_arusoaie"]
            ],
            "Grafică pe calculator": [
                hardcoded_professors["constantin_lucian_ghirvu"],
                hardcoded_professors["nicolae_eugen_croitoru"]
            ],
            "Programare bazată pe reguli": [
                hardcoded_professors["ionut_pistol"]
            ],
            "TPPA": [
                hardcoded_professors["dragos_gavrilut"]
            ],
            "ARMS": [
                hardcoded_professors["anca_vitcu"]
            ],
            "ACTN": [
                hardcoded_professors["sorin_iftene"]
            ],
            "PCPIT": [
                hardcoded_professors["armanu_nicoleta"]
            ],
            "Programare MS-Office": [
                hardcoded_professors["vlad_radulescu"]
            ],
            "Cloud Computing": [
                hardcoded_professors["lenuta_alboaie"]
            ],
            "MLMOS": [
                hardcoded_professors["corneliu_sabin_buraga"]
            ],
            "Rețele Petrii și aplicații": [
                hardcoded_professors["oana_captarencu"]
            ],
            "Smart Card-uri și Aplicații": [
                hardcoded_professors["catalin_birjoveanu"]
            ],
            "TSP": [
                hardcoded_professors["ioan_asiminei"]
            ],
            "TILU": [
                hardcoded_professors["diana_trandabat"]
            ]
        }
    }

    for laboratory_semester in laboratories_per_semesters:
        for laboratory in laboratories_per_semesters[laboratory_semester]:
            _laboratory_service.add_laboratory(
                _name=laboratory,
                _description="Descriere pentru materia {}".format(laboratory),
                _year=int(laboratory_semester[2]),
                _semester=int(laboratory_semester[7]),
                _hardcoded_professors=laboratories_per_semesters[laboratory_semester][laboratory]
            )


def generate_courses_pdfs():
    courses = _course_service.get_all_courses()
    for course in courses:
        root_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        upload_folder_path = os.path.join(root_path, f'Presentation\\static\\pdf\\courses\\{course.uuid}')
        if not os.path.isdir(upload_folder_path):
            os.mkdir(upload_folder_path)
        for i in range(1, 15):
            _course_pdf_service.add(
                **{
                    "course_uuid": course.uuid,
                    "path": f"curs{i}.pdf",
                    "name": f"Curs {i}"
                }
            )


def generate_laboratories_pdfs():
    laboratories = _laboratory_service.get_all_laboratories()
    for laboratory in laboratories:
        root_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        upload_folder_path = os.path.join(root_path, f'Presentation\\static\\pdf\\laboratories\\{laboratory.uuid}')
        if not os.path.isdir(upload_folder_path):
            os.mkdir(upload_folder_path)
        for i in range(1, 15):
            _laboratory_pdf_service.add(
                **{
                    "laboratory_uuid": laboratory.uuid,
                    "path": f"laborator{i}.pdf",
                    "name": f"Laborator {i}"
                }
            )


def generate_laboratories_homeworks():
    laboratories = _laboratory_service.get_all_laboratories()
    for laboratory in laboratories:
        root_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        upload_folder_path = os.path.join(root_path, f'Presentation\\static\\homeworks\\{laboratory.uuid}')
        if not os.path.isdir(upload_folder_path):
            os.mkdir(upload_folder_path)
        for i in range(1, 15):
            _laboratory_homework_service.add(
                **{
                    "laboratory_uuid": laboratory.uuid,
                    "path": f"Tema{i}.pdf",
                    "name": f"Tema {i}"
                }
            )


def get_random_nr(min_val, max_val, step=None, with_zero_before=False):
    if step:
        generated_nr = choice([nr for nr in range(min_val, max_val, step)])
    else:
        generated_nr = randint(min_val, max_val - 1)
    if with_zero_before:
        if len(str(generated_nr)) == 1:
            return f'0{generated_nr}'
        else:
            return generated_nr
    return generated_nr


def generate_courses_exams():
    details = ["Aici ar trebui sa fie detaliile cursului"]
    datetime_format = '%Y-%m-%d %H:%M:%S'

    courses_pdfs = _course_pdf_service.get_all()
    for course_pdf in courses_pdfs:
        date_time_str = f'2021-02-{get_random_nr(min_val=1, max_val=28, with_zero_before=True)} ' \
                        f'{get_random_nr(min_val=8, max_val=21, with_zero_before=True)}:' \
                        f'{get_random_nr(min_val=0, max_val=60, step=5, with_zero_before=True)}:' \
                        f'00'
        date_time_obj = datetime.strptime(date_time_str, datetime_format)
        _course_exam_service.add(
            **{
                "course_pdf_uuid": course_pdf.uuid,
                "duration_minutes": get_random_nr(5, 60, step=5),
                "start_date": date_time_obj,
                "details": details[0]
            }
        )


def generate_course_exam_questions():
    courses_exams = _course_exam_service.get_all()
    for course_exam in courses_exams:
        for i in range(1, 11):
            _course_exam_question_service.add(
                **{
                    "course_exam_uuid": course_exam.uuid,
                    "question": f'Intrebare nr. {i}',
                    "score": 1
                }
            )


def generate_course_exam_answers():
    courses_exams_questions = _course_exam_question_service.get_all()
    for course_exam_question in courses_exams_questions:
        random_nr = randint(1, 4)
        for i in range(1, 5):
            is_correct = i == random_nr
            _course_exam_question_answer_service.add(
                **{
                    "course_exam_question_uuid": course_exam_question.uuid,
                    "answer": f'Raspuns nr. {i}',
                    "is_correct": is_correct
                }
            )


def rename_and_move_python_pdfs(uuid):
    utils_folder = os.path.dirname(os.path.abspath(__file__))
    python_course_folder = os.path.join(os.path.dirname(os.path.dirname(utils_folder)), f'Presentation\static\pdf\{uuid}')
    pdfs_folder = os.path.join(os.path.dirname(os.path.dirname(utils_folder)), 'Presentation\static\pdf\python_pdfs')

    for file_pdf in os.listdir(pdfs_folder):
        os.rename(os.path.join(pdfs_folder, file_pdf), os.path.join(python_course_folder, file_pdf))
        shutil.move(os.path.join(pdfs_folder, file_pdf), os.path.join(python_course_folder, file_pdf))
        os.replace(os.path.join(pdfs_folder, file_pdf), os.path.join(python_course_folder, file_pdf))


def modify_python_course():
    courses = _course_service.get_all_courses()

    for course in courses:
        if course.name == 'Programare în Python':
            _course_service.update(course.uuid, **{
                'description': 'La acest curs veti invata incepand de la bazele limbajului python, pana la lucruri mai '
                               'complexe'
            })

            course_pdfs = _course_pdf_service.get_by_course_uuid(course.uuid)

            if len(course_pdfs) == 14:
                course_exam = _course_exam_service.get_by_course_pdf_uuid(course_pdfs[-1].uuid)
                course_exam_questions = _course_exam_question_service.get_by_course_exam_uuid(course_exam.uuid)
                for course_exam_question in course_exam_questions:
                    course_exam_questions_answers = \
                        _course_exam_question_answer_service.get_by_course_exam_question_uuid(course_exam_question.uuid)
                    for course_exam_questions_answer in course_exam_questions_answers:
                        _course_exam_question_answer_service.delete_by_uuid(course_exam_questions_answer.uuid)
                    _course_exam_question_service.delete_by_uuid(course_exam_question.uuid)
                _course_exam_service.delete_by_uuid(course_exam.uuid)
                _course_pdf_service.delete_by_uuid(course_pdfs[-1].uuid)

            course_pdfs = _course_pdf_service.get_by_course_uuid(course.uuid)
            courses_name = ['Introduction', 'Sequences', 'Dictionaries & sets', 'Exceptions & modules',
                            'Modules & Packages', 'Regular expressions', 'Serialization, Time module, Random Module',
                            'Networking', 'Classes - 1', 'Classes - 2', 'Threading and synchronization',
                            'C/C++ bindings - 1', 'C/C++ bindings - 2']
            for idx, course_pdf in enumerate(course_pdfs):
                _course_pdf_service.update(course_pdf.uuid, **{
                    'name': courses_name[idx]
                })

            rename_and_move_python_pdfs(course.uuid)
            questions = [
                'Pentru a putea folosi o variabila ca fiind globala folosim urmatorul cuvant cheie',
                'Pentru declararea unei functii se foloseste cuvantul cheie',
                'Structura corecta a for-ului din python este urmatoarea',
                'Care din urmatoarele este o functie built-in pentru stringuri',
                'Stringul in python este considerat o clasa?',
                'Care din urmatorii operatori este echivalentul ridicarii la putere (pow din C)',
                'Ce functie se foloseste pentru aflarea tipului unei variabile',
                'Cum se acceseaza ultimul caracter dintr-un string?',
                'Cum se declara o functie cu nume variabil de parametrii',
                'In python 3 functiile trebuie sa aiba un tip de data?'
            ]
            answers = [
                [
                    {
                        'answer': 'globally',
                        'is_correct': False,
                    },
                    {
                        'answer': 'global',
                        'is_correct': True
                    },
                    {
                        'answer': 'g',
                        'is_correct': False
                    },
                    {
                        'answer': 'external',
                        'is_correct': False
                    }
                ],
                [
                    {
                        'answer': 'function',
                        'is_correct': False,
                    },
                    {
                        'answer': 'func',
                        'is_correct': False
                    },
                    {
                        'answer': 'def',
                        'is_correct': True
                    },
                    {
                        'answer': 'definition',
                        'is_correct': False
                    }
                ],
                [
                    {
                        'answer': 'for(declaratii;conditii;incrementari)',
                        'is_correct': False,
                    },
                    {
                        'answer': 'for(declaratii,conditii,incrementari)',
                        'is_correct': False
                    },
                    {
                        'answer': 'for lista_variabile in lista',
                        'is_correct': True
                    },
                    {
                        'answer': 'for declaratii;conditii;incrementari',
                        'is_correct': False
                    }
                ],
                [
                    {
                        'answer': 'chr',
                        'is_correct': True,
                    },
                    {
                        'answer': 'toLower',
                        'is_correct': False
                    },
                    {
                        'answer': 'toUpper',
                        'is_correct': False
                    },
                    {
                        'answer': 'toTitle',
                        'is_correct': False
                    }
                ],
                [
                    {
                        'answer': 'uneori',
                        'is_correct': False,
                    },
                    {
                        'answer': 'da',
                        'is_correct': True
                    },
                    {
                        'answer': 'nu',
                        'is_correct': False
                    },
                    {
                        'answer': 'depinde de initializare',
                        'is_correct': False
                    }
                ],
                [
                    {
                        'answer': 'pow',
                        'is_correct': False,
                    },
                    {
                        'answer': 'power',
                        'is_correct': False
                    },
                    {
                        'answer': '**',
                        'is_correct': True
                    },
                    {
                        'answer': '^',
                        'is_correct': False
                    }
                ],
                [
                    {
                        'answer': 'typeof',
                        'is_correct': False,
                    },
                    {
                        'answer': 'type_of',
                        'is_correct': False
                    },
                    {
                        'answer': 'type',
                        'is_correct': True
                    },
                    {
                        'answer': 'type_of',
                        'is_correct': False
                    }
                ],
                [
                    {
                        'answer': 'nume_string[length(nume_variabila)]',
                        'is_correct': False,
                    },
                    {
                        'answer': 'nume_string[-1]',
                        'is_correct': True
                    },
                    {
                        'answer': 'nume_string[:last]',
                        'is_correct': False
                    },
                    {
                        'answer': 'nume_string[:-1]',
                        'is_correct': False
                    }
                ],
                [
                    {
                        'answer': 'def function_name(...)',
                        'is_correct': False,
                    },
                    {
                        'answer': 'def function_name(args[])',
                        'is_correct': False
                    },
                    {
                        'answer': 'def function_name(args...)',
                        'is_correct': False
                    },
                    {
                        'answer': 'def function_name(*args)',
                        'is_correct': True
                    }
                ],
                [
                    {
                        'answer': 'nu',
                        'is_correct': True,
                    },
                    {
                        'answer': 'da',
                        'is_correct': False
                    },
                    {
                        'answer': 'da, doar cand vorbim de metode declarate in clasa',
                        'is_correct': False
                    },
                    {
                        'answer': 'da, de exemplu def int function_name(parameters)',
                        'is_correct': False
                    }
                ]
            ]

            course_exam = _course_exam_service.get_by_course_pdf_uuid(course_pdfs[0].uuid)
            course_exam_questions = _course_exam_question_service.get_by_course_exam_uuid(course_exam.uuid)

            for idx_question, question in enumerate(course_exam_questions):
                _course_exam_question_service.update(question.uuid, **{
                    'question': questions[idx_question]
                })
                course_exam_question_answers = \
                    _course_exam_question_answer_service.get_by_course_exam_question_uuid(question.uuid)

                for idx_answer, answer in enumerate(course_exam_question_answers):
                    _course_exam_question_answer_service.update(answer.uuid, **{
                        'answer': answers[idx_question][idx_answer]['answer'],
                        'is_correct': answers[idx_question][idx_answer]['is_correct'],
                    })
