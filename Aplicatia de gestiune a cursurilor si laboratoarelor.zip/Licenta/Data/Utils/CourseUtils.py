from Bussiness.Services.CourseService import CourseService
from Bussiness.Services.LaboratoryService import LaboratoryService

_course_service = CourseService()
_laboratory_service = LaboratoryService()


def return_courses_json():
    _courses = _course_service.get_all_courses()
    _courses_json = dict()
    for course in _courses:
        if "{}_{}".format(course.year, course.semester) not in _courses_json:
            _courses_json["{}_{}".format(course.year, course.semester)] = []
            _courses_json["{}_{}".format(course.year, course.semester)].append([
                course.uuid, course.name])
        else:
            _courses_json["{}_{}".format(course.year, course.semester)].append([
                course.uuid, course.name])

    return _courses_json


def return_laboratories_json():
    _laboratories = _laboratory_service.get_all_laboratories()
    _laboratories_json = dict()
    for laboratory in _laboratories:
        if "{}_{}".format(laboratory.year, laboratory.semester) not in _laboratories_json:
            _laboratories_json["{}_{}".format(laboratory.year, laboratory.semester)] = []
            _laboratories_json["{}_{}".format(laboratory.year, laboratory.semester)].append([
                laboratory.uuid, laboratory.name])
        else:
            _laboratories_json["{}_{}".format(laboratory.year, laboratory.semester)].append([
                laboratory.uuid, laboratory.name])

    return _laboratories_json