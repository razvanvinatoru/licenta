from datetime import datetime
from pytz import timezone


def get_datetime_now():
    bucharest = timezone('Europe/Bucharest')
    bucharest_time = datetime.now(bucharest)
    bucharest_strftime = bucharest_time.strftime('%Y-%m-%d %H:%M:%S')
    return datetime.strptime(bucharest_strftime, "%Y-%m-%d %H:%M:%S")


def format_comment_date(date):
    date = datetime.now() - date

    seconds = date.total_seconds()
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60

    if hours > 24 * 365 * 2:
        return "acum " + str(int(hours / ( 24 * 2 * 365))) + " ani"
    if hours > 24 * 365:
        return "acum un an"
    if hours >= 48:
        return "acum " + str(int(hours / 24)) + " zile"
    if 24 <= int(hours) < 48:
        return "acum o zi"
    if hours > 1:
        return "acum " + str(int(hours)) + " ore"
    if hours == 1:
        return "acum o ora"
    if minutes > 1:
        return "acum " + str(int(minutes)) + " minute"
    if minutes == 1:
        return "acum un minut"

    return "chiar acum"


def format_date_tooltip(date):
    if date is None:
        return None
    else:
        day = str(date.day)
        if len(day) == 1:
            date_formatted = "0" + day
        else:
            date_formatted = day

        date_formatted += " " + date.strftime("%B")[0:3] + " "

        hour = str(date.hour)
        if len(hour) == 1:
            date_formatted += "0" + hour
        else:
            date_formatted += hour

        date_formatted += ":"
        minute = str(date.minute)
        if len(minute) == 1:
            date_formatted += "0" + minute
        else:
            date_formatted += minute

        return date_formatted
