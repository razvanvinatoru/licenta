from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField


class StudentRegistrationForm(FlaskForm):
    lastname = StringField('Numele tau', render_kw={"placeholder": "Introduceti numele"})
    firstname = StringField('Prenumele tau', render_kw={"placeholder": "Introduceti prenumele"})
    email = StringField('Email', render_kw={"placeholder": "Introduceti email-ul"})
    password = PasswordField('Parola', render_kw={"placeholder": "Introduceti parola"})
    confirm_password = PasswordField('Confirmare parola', render_kw={"placeholder": "Confirmati parola"})
    submit = SubmitField('Inregistrare')
