from flask_wtf import FlaskForm
from wtforms import StringField, SelectField, TextAreaField, SubmitField


class EditDetailsForm(FlaskForm):
    name = StringField('Nume:', render_kw={"placeholder": "Noul nume..."})
    email = StringField('Email:', render_kw={"placeholder": "Noul email..."})
    group = SelectField('Grupa:', choices=[('A1', 'A1'), ('A2', 'A2'), ('A3', 'A3'), ('A4', 'A4'), ('A5', 'A5'),
                                           ('A6', 'A6'), ('A7', 'A7'), ('B1', 'B1'), ('B2', 'B2'), ('B3', 'B3'),
                                           ('B4', 'B4'), ('B5', 'B5'), ('B6', 'B6'), ('B7', 'B7'), ('E', 'E')])
    year = SelectField('Anul:', choices=[('1', 'Anul I'), ('2', 'Anul II'), ('3', 'Anul III'), ('cursant', 'Cursant')])
    student_description = TextAreaField('Descriere', render_kw={"placeholder": "Noua descriere..."})
    submitName = SubmitField(u"\u2714")
    submitEmail = SubmitField(u"\u2714")
    submitGroup = SubmitField(u"\u2714")
    submitYear = SubmitField(u"\u2714")
    submitStudentDescription = SubmitField(u"\u2714")
