from flask_wtf import FlaskForm
from wtforms import TextAreaField, SubmitField


class ContactMessagesForm(FlaskForm):
    text = TextAreaField()
    submit = SubmitField('Trimite')
