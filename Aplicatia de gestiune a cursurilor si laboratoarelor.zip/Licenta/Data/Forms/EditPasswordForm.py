from flask_wtf import FlaskForm
from wtforms import PasswordField, SubmitField


class EditPasswordForm(FlaskForm):
    password = PasswordField('Parola actuala: ', render_kw={"placeholder": "Parola actuala.."})
    new_password = PasswordField('Parola noua: ', render_kw={"placeholder": "Parola noua.."})
    confirm_new_password = PasswordField('Confirma parola: ', render_kw={"placeholder": "Confirma parola.."})
    submitPassword = SubmitField('Schimba')
