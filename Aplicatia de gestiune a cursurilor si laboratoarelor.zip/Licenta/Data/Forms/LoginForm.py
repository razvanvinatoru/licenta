from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField


class LoginForm(FlaskForm):
    email = StringField('Email', render_kw={"placeholder": "Introduceti email-ul"})
    password = PasswordField('Parola', render_kw={"placeholder": "Introduceti parola"})
    submit = SubmitField('Logare')
